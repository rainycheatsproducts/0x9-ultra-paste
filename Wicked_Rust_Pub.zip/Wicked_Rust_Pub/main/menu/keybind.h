#pragma once
#include "../driver/string/estr.hpp"
#include "../config/config.hpp"
#include "../../ui/imgui.h"

namespace aimbotkey 
{
	int realkey;//aimbot
	int keystatus;//aimbot
	static const char* keyNames[] = {
	"",
	"Left Mouse",
	"Right Mouse",
	"Cancel",
	"Middle Mouse",
	"Mouse 5",
	"Mouse 4",
	"",
	"Backspace",
	"Tab",
	"",
	"",
	"Clear",
	"Enter",
	"",
	"",
	"Shift",
	"Control",
	"Alt",
	"Pause",
	"Caps",
	"",
	"",
	"",
	"",
	"",
	"",
	"Escape",
	"",
	"",
	"",
	"",
	"Space",
	"Page Up",
	"Page Down",
	"End",
	"Home",
	"Left",
	"Up",
	"Right",
	"Down",
	"",
	"",
	"",
	"Print",
	"Insert",
	"Delete",
	"",
	"0",
	"1",
	"2",
	"3",
	"4",
	"5",
	"6",
	"7",
	"8",
	"9",
	"",
	"",
	"",
	"",
	"",
	"",
	"",
	"A",
	"B",
	"C",
	"D",
	"E",
	"F",
	"G",
	"H",
	"I",
	"J",
	"K",
	"L",
	"M",
	"N",
	"O",
	"P",
	"Q",
	"R",
	"S",
	"T",
	"U",
	"V",
	"W",
	"X",
	"Y",
	"Z",
	"",
	"",
	"",
	"",
	"",
	"Numpad 0",
	"Numpad 1",
	"Numpad 2",
	"Numpad 3",
	"Numpad 4",
	"Numpad 5",
	"Numpad 6",
	"Numpad 7",
	"Numpad 8",
	"Numpad 9",
	"Multiply",
	"Add",
	"",
	"Subtract",
	"Decimal",
	"Divide",
	"F1",
	"F2",
	"F3",
	"F4",
	"F5",
	"F6",
	"F7",
	"F8",
	"F9",
	"F10",
	"F11",
	"F12",
	};

	bool GetKey(int key)
	{
		realkey = key;
		return true;
	}

	void ChangeKey(void* blank)
	{
		keystatus = 1;
		while (true)
		{
			for (int i = 0; i < 0x87; i++)
			{
				if (GetKeyState(i) & 0x8000)
				{
					config.Includes.Aimbot.keybindaim = i;
					keystatus = 0;
					return;
				}
			}
		}
	}

	static bool Items_ArrayGetter(void* data, int idx, const char** out_text)
	{
		const char* const* items = (const char* const*)data;
		if (out_text)
			*out_text = items[idx];
		return true;
	}

	void AimkeyButton(int aimkey, void* changekey, int status)
	{
		const char* preview_value = NULL;
		if (aimkey >= 0 && aimkey < IM_ARRAYSIZE(keyNames))
			Items_ArrayGetter(keyNames, aimkey, &preview_value);

		std::string aimkeys;
		if (preview_value == NULL)
			aimkeys = (e("Select Key"));
		else
			aimkeys = preview_value;

		if (status == 1)
		{
			aimkeys = (e("bind"));
		}
		if (ImGui::Button(aimkeys.c_str(), ImVec2(75, 20)))
		{
			if (status == 0)
			{
				CreateThread(0, 0, (LPTHREAD_START_ROUTINE)changekey, nullptr, 0, nullptr);
			}
		}
	}
}

namespace flyhack 
{
	int realkey0;//aimbot
	int keystatus0;//aimbot
	static const char* keyNames[] = {
	"",
	"Left Mouse",
	"Right Mouse",
	"Cancel",
	"Middle Mouse",
	"Mouse 5",
	"Mouse 4",
	"",
	"Backspace",
	"Tab",
	"",
	"",
	"Clear",
	"Enter",
	"",
	"",
	"Shift",
	"Control",
	"Alt",
	"Pause",
	"Caps",
	"",
	"",
	"",
	"",
	"",
	"",
	"Escape",
	"",
	"",
	"",
	"",
	"Space",
	"Page Up",
	"Page Down",
	"End",
	"Home",
	"Left",
	"Up",
	"Right",
	"Down",
	"",
	"",
	"",
	"Print",
	"Insert",
	"Delete",
	"",
	"0",
	"1",
	"2",
	"3",
	"4",
	"5",
	"6",
	"7",
	"8",
	"9",
	"",
	"",
	"",
	"",
	"",
	"",
	"",
	"A",
	"B",
	"C",
	"D",
	"E",
	"F",
	"G",
	"H",
	"I",
	"J",
	"K",
	"L",
	"M",
	"N",
	"O",
	"P",
	"Q",
	"R",
	"S",
	"T",
	"U",
	"V",
	"W",
	"X",
	"Y",
	"Z",
	"",
	"",
	"",
	"",
	"",
	"Numpad 0",
	"Numpad 1",
	"Numpad 2",
	"Numpad 3",
	"Numpad 4",
	"Numpad 5",
	"Numpad 6",
	"Numpad 7",
	"Numpad 8",
	"Numpad 9",
	"Multiply",
	"Add",
	"",
	"Subtract",
	"Decimal",
	"Divide",
	"F1",
	"F2",
	"F3",
	"F4",
	"F5",
	"F6",
	"F7",
	"F8",
	"F9",
	"F10",
	"F11",
	"F12",
	};

	bool GetKey(int key)
	{
		realkey0 = key;
		return true;
	}

	void ChangeKey(void* blank)
	{
		keystatus0 = 1;
		while (true)
		{
			for (int i = 0; i < 0x87; i++)
			{
				if (GetKeyState(i) & 0x8000)
				{
					config.Includes.Misc.flyhackkey = i;
					keystatus0 = 0;
					return;
				}
			}
		}
	}

	static bool Items_ArrayGetter(void* data, int idx, const char** out_text)
	{
		const char* const* items = (const char* const*)data;
		if (out_text)
			*out_text = items[idx];
		return true;
	}

	void FlykeyButton(int aimkey, void* changekey, int status)
	{
		const char* preview_value = NULL;
		if (aimkey >= 0 && aimkey < IM_ARRAYSIZE(keyNames))
			Items_ArrayGetter(keyNames, aimkey, &preview_value);

		std::string aimkeys;
		if (preview_value == NULL)
			aimkeys = (e("Select Key"));
		else
			aimkeys = preview_value;

		if (status == 1)
		{
			aimkeys = (e("bind"));
		}
		if (ImGui::Button(aimkeys.c_str(), ImVec2(75, 20)))
		{
			if (status == 0)
			{
				CreateThread(0, 0, (LPTHREAD_START_ROUTINE)changekey, nullptr, 0, nullptr);
			}
		}
	}
}

namespace longneckright
{
	int realkey3;//aimbot
	int keystatus3;//aimbot
	static const char* keyNames4[] = {
	"",
	"Left Mouse",
	"Right Mouse",
	"Cancel",
	"Middle Mouse",
	"Mouse 5",
	"Mouse 4",
	"",
	"Backspace",
	"Tab",
	"",
	"",
	"Clear",
	"Enter",
	"",
	"",
	"Shift",
	"Control",
	"Alt",
	"Pause",
	"Caps",
	"",
	"",
	"",
	"",
	"",
	"",
	"Escape",
	"",
	"",
	"",
	"",
	"Space",
	"Page Up",
	"Page Down",
	"End",
	"Home",
	"Left",
	"Up",
	"Right",
	"Down",
	"",
	"",
	"",
	"Print",
	"Insert",
	"Delete",
	"",
	"0",
	"1",
	"2",
	"3",
	"4",
	"5",
	"6",
	"7",
	"8",
	"9",
	"",
	"",
	"",
	"",
	"",
	"",
	"",
	"A",
	"B",
	"C",
	"D",
	"E",
	"F",
	"G",
	"H",
	"I",
	"J",
	"K",
	"L",
	"M",
	"N",
	"O",
	"P",
	"Q",
	"R",
	"S",
	"T",
	"U",
	"V",
	"W",
	"X",
	"Y",
	"Z",
	"",
	"",
	"",
	"",
	"",
	"Numpad 0",
	"Numpad 1",
	"Numpad 2",
	"Numpad 3",
	"Numpad 4",
	"Numpad 5",
	"Numpad 6",
	"Numpad 7",
	"Numpad 8",
	"Numpad 9",
	"Multiply",
	"Add",
	"",
	"Subtract",
	"Decimal",
	"Divide",
	"F1",
	"F2",
	"F3",
	"F4",
	"F5",
	"F6",
	"F7",
	"F8",
	"F9",
	"F10",
	"F11",
	"F12",
	};

	bool GetKey4(int key4)
	{
		realkey3 = key4;
		return true;
	}

	void ChangeKey4(void* blank4)
	{
		keystatus3 = 1;
		while (true)
		{
			for (int i = 0; i < 0x87; i++)
			{
				if (GetKeyState(i) & 0x8000)
				{
					config.Includes.Aimbot.LongNeckRight = i;
					keystatus3 = 0;
					return;
				}
			}
		}
	}

	static bool Items_ArrayGetter4(void* data4, int idx4, const char** out_text4)
	{
		const char* const* items = (const char* const*)data4;
		if (out_text4)
			*out_text4 = items[idx4];
		return true;
	}

	void longneckrightButton(int aimkey4, void* changekey4, int status4)
	{
		const char* preview_value = NULL;
		if (aimkey4 >= 0 && aimkey4 < IM_ARRAYSIZE(keyNames4))
			Items_ArrayGetter4(keyNames4, aimkey4, &preview_value);

		std::string aimkeys4;
		if (preview_value == NULL)
			aimkeys4 = (e("Select Key"));
		else
			aimkeys4 = preview_value;

		if (status4 == 1)
		{
			aimkeys4 = (e("bind"));
		}
		if (ImGui::Button4(aimkeys4.c_str(), ImVec2(75, 20)))
		{
			if (status4 == 0)
			{
				CreateThread(0, 0, (LPTHREAD_START_ROUTINE)changekey4, nullptr, 0, nullptr);
			}
		}
	}
}

namespace longneckleft
{
	int realkey2;//aimbot
	int keystatus2;//aimbot
	static const char* keyNames3[] = {
	"",
	"Left Mouse",
	"Right Mouse",
	"Cancel",
	"Middle Mouse",
	"Mouse 5",
	"Mouse 4",
	"",
	"Backspace",
	"Tab",
	"",
	"",
	"Clear",
	"Enter",
	"",
	"",
	"Shift",
	"Control",
	"Alt",
	"Pause",
	"Caps",
	"",
	"",
	"",
	"",
	"",
	"",
	"Escape",
	"",
	"",
	"",
	"",
	"Space",
	"Page Up",
	"Page Down",
	"End",
	"Home",
	"Left",
	"Up",
	"Right",
	"Down",
	"",
	"",
	"",
	"Print",
	"Insert",
	"Delete",
	"",
	"0",
	"1",
	"2",
	"3",
	"4",
	"5",
	"6",
	"7",
	"8",
	"9",
	"",
	"",
	"",
	"",
	"",
	"",
	"",
	"A",
	"B",
	"C",
	"D",
	"E",
	"F",
	"G",
	"H",
	"I",
	"J",
	"K",
	"L",
	"M",
	"N",
	"O",
	"P",
	"Q",
	"R",
	"S",
	"T",
	"U",
	"V",
	"W",
	"X",
	"Y",
	"Z",
	"",
	"",
	"",
	"",
	"",
	"Numpad 0",
	"Numpad 1",
	"Numpad 2",
	"Numpad 3",
	"Numpad 4",
	"Numpad 5",
	"Numpad 6",
	"Numpad 7",
	"Numpad 8",
	"Numpad 9",
	"Multiply",
	"Add",
	"",
	"Subtract",
	"Decimal",
	"Divide",
	"F1",
	"F2",
	"F3",
	"F4",
	"F5",
	"F6",
	"F7",
	"F8",
	"F9",
	"F10",
	"F11",
	"F12",
	};

	bool GetKey3(int key3)
	{
		realkey2 = key3;
		return true;
	}

	void ChangeKey3(void* blank3)
	{
		keystatus2 = 1;
		while (true)
		{
			for (int i = 0; i < 0x87; i++)
			{
				if (GetKeyState(i) & 0x8000)
				{
					config.Includes.Aimbot.LongNeckLeft = i;
					keystatus2 = 0;
					return;
				}
			}
		}
	}

	static bool Items_ArrayGetter3(void* data3, int idx3, const char** out_text3)
	{
		const char* const* items = (const char* const*)data3;
		if (out_text3)
			*out_text3 = items[idx3];
		return true;
	}

	void longneckleftButton(int aimkey3, void* changekey3, int status3)
	{
		const char* preview_value = NULL;
		if (aimkey3 >= 0 && aimkey3 < IM_ARRAYSIZE(keyNames3))
			Items_ArrayGetter3(keyNames3, aimkey3, &preview_value);

		std::string aimkeys3;
		if (preview_value == NULL)
			aimkeys3 = (e("Select Key"));
		else
			aimkeys3 = preview_value;

		if (status3 == 1)
		{
			aimkeys3 = (e("bind"));
		}
		if (ImGui::Button3(aimkeys3.c_str(), ImVec2(75, 20)))
		{
			if (status3 == 0)
			{
				CreateThread(0, 0, (LPTHREAD_START_ROUTINE)changekey3, nullptr, 0, nullptr);
			}
		}
	}
}

namespace longneckup
{
	int realkey1;//aimbot
	int keystatus1;//aimbot
	static const char* keyNames2[] = {
	"",
	"Left Mouse",
	"Right Mouse",
	"Cancel",
	"Middle Mouse",
	"Mouse 5",
	"Mouse 4",
	"",
	"Backspace",
	"Tab",
	"",
	"",
	"Clear",
	"Enter",
	"",
	"",
	"Shift",
	"Control",
	"Alt",
	"Pause",
	"Caps",
	"",
	"",
	"",
	"",
	"",
	"",
	"Escape",
	"",
	"",
	"",
	"",
	"Space",
	"Page Up",
	"Page Down",
	"End",
	"Home",
	"Left",
	"Up",
	"Right",
	"Down",
	"",
	"",
	"",
	"Print",
	"Insert",
	"Delete",
	"",
	"0",
	"1",
	"2",
	"3",
	"4",
	"5",
	"6",
	"7",
	"8",
	"9",
	"",
	"",
	"",
	"",
	"",
	"",
	"",
	"A",
	"B",
	"C",
	"D",
	"E",
	"F",
	"G",
	"H",
	"I",
	"J",
	"K",
	"L",
	"M",
	"N",
	"O",
	"P",
	"Q",
	"R",
	"S",
	"T",
	"U",
	"V",
	"W",
	"X",
	"Y",
	"Z",
	"",
	"",
	"",
	"",
	"",
	"Numpad 0",
	"Numpad 1",
	"Numpad 2",
	"Numpad 3",
	"Numpad 4",
	"Numpad 5",
	"Numpad 6",
	"Numpad 7",
	"Numpad 8",
	"Numpad 9",
	"Multiply",
	"Add",
	"",
	"Subtract",
	"Decimal",
	"Divide",
	"F1",
	"F2",
	"F3",
	"F4",
	"F5",
	"F6",
	"F7",
	"F8",
	"F9",
	"F10",
	"F11",
	"F12",
	};

	bool GetKey2(int key2)
	{
		realkey1 = key2;
		return true;
	}

	void ChangeKey2(void* blank2)
	{
		keystatus1 = 1;
		while (true)
		{
			for (int i = 0; i < 0x87; i++)
			{
				if (GetKeyState(i) & 0x8000)
				{
					config.Includes.Aimbot.LongneckUp = i;
					keystatus1 = 0;
					return;
				}
			}
		}
	}

	static bool Items_ArrayGetter2(void* data2, int idx2, const char** out_text2)
	{
		const char* const* items = (const char* const*)data2;
		if (out_text2)
			*out_text2 = items[idx2];
		return true;
	}

	void longneckupButton(int aimkey2, void* changekey2, int status2)
	{
		const char* preview_value = NULL;
		if (aimkey2 >= 0 && aimkey2 < IM_ARRAYSIZE(keyNames2))
			Items_ArrayGetter2(keyNames2, aimkey2, &preview_value);

		std::string aimkeys2;
		if (preview_value == NULL)
			aimkeys2 = (e("Select Key"));
		else
			aimkeys2 = preview_value;

		if (status2 == 1)
		{
			aimkeys2 = (e("bind"));
		}
		if (ImGui::Button1(aimkeys2.c_str(), ImVec2(75, 20)))
		{
			if (status2 == 0)
			{
				CreateThread(0, 0, (LPTHREAD_START_ROUTINE)changekey2, nullptr, 0, nullptr);
			}
		}
	}
}

namespace longneckactive
{
	int realkey4;//aimbot
	int keystatus4;//aimbot
	static const char* keyNames1[] = {
	"",
	"Left Mouse",
	"Right Mouse",
	"Cancel",
	"Middle Mouse",
	"Mouse 5",
	"Mouse 4",
	"",
	"Backspace",
	"Tab",
	"",
	"",
	"Clear",
	"Enter",
	"",
	"",
	"Shift",
	"Control",
	"Alt",
	"Pause",
	"Caps",
	"",
	"",
	"",
	"",
	"",
	"",
	"Escape",
	"",
	"",
	"",
	"",
	"Space",
	"Page Up",
	"Page Down",
	"End",
	"Home",
	"Left",
	"Up",
	"Right",
	"Down",
	"",
	"",
	"",
	"Print",
	"Insert",
	"Delete",
	"",
	"0",
	"1",
	"2",
	"3",
	"4",
	"5",
	"6",
	"7",
	"8",
	"9",
	"",
	"",
	"",
	"",
	"",
	"",
	"",
	"A",
	"B",
	"C",
	"D",
	"E",
	"F",
	"G",
	"H",
	"I",
	"J",
	"K",
	"L",
	"M",
	"N",
	"O",
	"P",
	"Q",
	"R",
	"S",
	"T",
	"U",
	"V",
	"W",
	"X",
	"Y",
	"Z",
	"",
	"",
	"",
	"",
	"",
	"Numpad 0",
	"Numpad 1",
	"Numpad 2",
	"Numpad 3",
	"Numpad 4",
	"Numpad 5",
	"Numpad 6",
	"Numpad 7",
	"Numpad 8",
	"Numpad 9",
	"Multiply",
	"Add",
	"",
	"Subtract",
	"Decimal",
	"Divide",
	"F1",
	"F2",
	"F3",
	"F4",
	"F5",
	"F6",
	"F7",
	"F8",
	"F9",
	"F10",
	"F11",
	"F12",
	};

	bool GetKey1(int key1)
	{
		realkey4 = key1;
		return true;
	}

	void ChangeKey1(void* blank1)
	{
		keystatus4 = 1;
		while (true)
		{
			for (int i = 0; i < 0x87; i++)
			{
				if (GetKeyState(i) & 0x8000)
				{
					config.Includes.Aimbot.LongneckUp = i;
					keystatus4 = 0;
					return;
				}
			}
		}
	}

	static bool Items_ArrayGetter1(void* data1, int idx1, const char** out_text1)
	{
		const char* const* items = (const char* const*)data1;
		if (out_text1)
			*out_text1 = items[idx1];
		return true;
	}

	void longneckactButton(int aimkey1, void* changekey1, int status1)
	{
		const char* preview_value = NULL;
		if (aimkey1 >= 0 && aimkey1 < IM_ARRAYSIZE(keyNames1))
			Items_ArrayGetter1(keyNames1, aimkey1, &preview_value);

		std::string aimkeys1;
		if (preview_value == NULL)
			aimkeys1 = (e("Select Key"));
		else
			aimkeys1 = preview_value;

		if (status1 == 1)
		{
			aimkeys1 = (e("bind"));
		}
		if (ImGui::Button2(aimkeys1.c_str(), ImVec2(75, 20)))
		{
			if (status1 == 0)
			{
				CreateThread(0, 0, (LPTHREAD_START_ROUTINE)changekey1, nullptr, 0, nullptr);
			}
		}
	}
}