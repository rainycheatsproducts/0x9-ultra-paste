#pragma once
#include "../driver/imports.hpp"
#include "custom.h"
#include "keybind.h"
#include "font.h"
static int AimSystem_Tab = 0;
static int MiscSystem_Tab = 0;
static int VisualsSystem_Tab = 0;
static int SettingsSystem_Tab = 0;
static int WorldSystem_Tab = 0;
static int NPCSystem_Tab = 0;
static int WeapomSystem_Tab = 0;
ImFont* mine1;
ImFont* mine;
constexpr auto& config_items = config.get_configs();
static auto current_config = -1;
static char buffer[32];

namespace window
{
	auto render_menu ( ) -> void
	{
		SetNextWindowSize ( ImVec2 ( config.Includes.Setiings.width + 15, config.Includes.Setiings.height + 15 ) );
		SetNextWindowPos ( ImVec2 ( -10, -10 ) );    
		SetNextWindowBgAlpha ( .25f );
		Begin(e("##0x9 background"), &config.Includes.Setiings.showing, ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoBringToFrontOnFocus | ImGuiWindowFlags_NoMove);{}ImGui::End();

		geo::vec2_t window_pos;

		SetNextWindowSize ( { 480, 410 }, ImGuiCond_Always );
		Begin(e("###0x9"), &config.Includes.Setiings.showing, ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoResize);
		{
			auto draw = GetWindowDrawList();
			ImVec2 pos = GetWindowPos();
			ImVec2 size = GetWindowSize();
			ImGuiContext& g = *GImGui;

			if ((size_t)(current_config) >= config_items.size())
				current_config = -1;

			draw->AddRectFilled({ pos.x + 5,pos.y + 3 }, { pos.x + 495, pos.y + 33 }, ImColor(12, 12, 12, 200), 0, 0);
			draw->AddRect({ pos.x + 5,pos.y + 3 }, { pos.x + 495, pos.y + 27 }, ImColor(3, 3, 3, 235), 0, 0, 1.3f);
			draw->AddRect({ pos.x + 4,pos.y + 2 }, { pos.x + 496, pos.y + 28 }, ImColor(20, 20, 20, 255), 0, 0, .8f);

			SetCursorPos(ImVec2(1, 1));
			BeginGroup();
			ImGui::PushFont(mine1);
			if (p_interface::tab(e("Aimbot System"), 0 == config.Includes.Setiings.m_bCurrentTab)) { config.Includes.Setiings.m_bCurrentTab = 0; }SameLine();
			if (p_interface::tab(e("Miscellaneous"), 1 == config.Includes.Setiings.m_bCurrentTab)) { config.Includes.Setiings.m_bCurrentTab = 1; }SameLine();
			if (p_interface::tab(e("Player Visual"), 3 == config.Includes.Setiings.m_bCurrentTab)) { config.Includes.Setiings.m_bCurrentTab = 3; }SameLine();
			if (p_interface::tab(e("Npc Visual"), 4 == config.Includes.Setiings.m_bCurrentTab)) { config.Includes.Setiings.m_bCurrentTab = 4; }SameLine();
			if (p_interface::tab(e("World Visual"), 5 == config.Includes.Setiings.m_bCurrentTab)) { config.Includes.Setiings.m_bCurrentTab = 5; }SameLine();
			if (p_interface::tab(e("Menu System"), 6 == config.Includes.Setiings.m_bCurrentTab)) { config.Includes.Setiings.m_bCurrentTab = 6; }
			ImGui::PopFont();
			EndGroup();

			if (config.Includes.Setiings.m_bCurrentTab == 0) 
			{
				if (AimSystem_Tab == 0)
				{

					draw->AddRectFilled({ pos.x + 15,pos.y + 35 }, { pos.x + 220, pos.y + 387 }, ImColor(12, 12, 12, 255), 0, 0);
					draw->AddRect({ pos.x + 15,pos.y + 35 }, { pos.x + 220, pos.y + 387 }, ImColor(3, 3, 3, 235), 0, 0, 1.3f);
					draw->AddRect({ pos.x + 14,pos.y + 34 }, { pos.x + 221, pos.y + 388 }, ImColor(20, 20, 20, 255), 0, 0, .8f);
					draw->AddText({ pos.x + 89 ,pos.y + 40 }, ImColor(255, 255, 255), "Aim");
					{
						SetCursorPosX(80);
						SetCursorPosY(80);
						Checkbox(e("Enable"), &config.Includes.Aimbot.enableaim);
						if (config.Includes.Aimbot.enableaim) {
							SetCursorPosX(80);
							SetCursorPosY(95);
							Checkbox(e("Silent Aim"), &config.Includes.Aimbot.Silentaim);
							SetCursorPosX(80);
							SetCursorPosY(110);
							Checkbox(e("Memory Aim"), &config.Includes.Aimbot.memoryaim);
						}
					}
					draw->AddRectFilled({ pos.x + 234,pos.y + 35 }, { pos.x + 440, pos.y + 387 }, ImColor(12, 12, 12, 255), 0, 0);
					draw->AddRect({ pos.x + 234,pos.y + 35 }, { pos.x + 440, pos.y + 387 }, ImColor(3, 3, 3, 235), 0, 0, 1.3f);
					draw->AddRect({ pos.x + 233,pos.y + 34 }, { pos.x + 441, pos.y + 388 }, ImColor(20, 20, 20, 255), 0, 0, .8f);
					draw->AddText({ pos.x + 289 ,pos.y + 40 }, ImColor(255, 255, 255), "Aim Toggles");
					{
								SetCursorPosX(300);
								SetCursorPosY(80);
								Text(e("Aim Key"));
								SetCursorPosX(290);
								SetCursorPosY(109);
								aimbotkey::AimkeyButton(config.Includes.Aimbot.keybindaim, aimbotkey::ChangeKey, aimbotkey::keystatus);
								SetCursorPosX(240);
								SetCursorPosY(145);
								SliderFloat(e("circle fov"), &config.Includes.Setiings.fov, 25.00f, 540.00f, "%.2f");
					}
				}
			}

			if (config.Includes.Setiings.m_bCurrentTab == 1)
			{
				if (MiscSystem_Tab == 0)
				{
					draw->AddRectFilled({ pos.x + 15,pos.y + 35 }, { pos.x + 220, pos.y + 387 }, ImColor(12, 12, 12, 255), 0, 0);
					draw->AddRect({ pos.x + 15,pos.y + 35 }, { pos.x + 220, pos.y + 387 }, ImColor(3, 3, 3, 235), 0, 0, 1.3f);
					draw->AddRect({ pos.x + 14,pos.y + 34 }, { pos.x + 221, pos.y + 388 }, ImColor(20, 20, 20, 255), 0, 0, .8f);
					draw->AddText({ pos.x + 89 ,pos.y + 40 }, ImColor(255, 255, 255), "Miscellaneous");
					{
						SetCursorPosX(80);
						SetCursorPosY(80);
						Checkbox(e("spyder man"), &config.Includes.Movement.spiderman);
						SetCursorPosX(80);
						SetCursorPosY(95);
						Checkbox(e("infinite jump"), &config.Includes.Movement.infinitejump);
						SetCursorPosX(80);
						SetCursorPosY(110);
						Checkbox(e("always Sprint"), &config.Includes.Movement.omnisprint);
						SetCursorPosX(80);
						SetCursorPosY(125);
						Checkbox(e("shoot mounted"), &config.Includes.Movement.holditemswhilemounted);
						SetCursorPosX(80);
						SetCursorPosY(140);
						Checkbox(e("Fly"), &config.Includes.Misc.flyhack);
						SetCursorPosX(80);
						SetCursorPosY(165);
						Checkbox(e("No Recoil"), &config.Includes.Misc.norecoli);
						SetCursorPosX(80);
						SetCursorPosY(180);
						Checkbox(e("No Spread"), &config.Includes.Misc.nospread);
						SetCursorPosX(80);
						SetCursorPosY(195);
						Checkbox(e("thick bullet"), &config.Includes.Misc.thickbullet);
						SetCursorPosX(80);
						SetCursorPosY(210);
						Checkbox(e("one tap eoka"), &config.Includes.Misc.insteoka);
						SetCursorPosX(80);
						SetCursorPosY(235);
						Checkbox(e("fast bow"), &config.Includes.Misc.instantbow);
						SetCursorPosX(80);
						SetCursorPosY(250);
						Checkbox(e("automatic"), &config.Includes.Misc.automatic);
						SetCursorPosX(80);
						SetCursorPosY(265);
						Checkbox(e("No Sway"), &config.Includes.Misc.nosway);
						SetCursorPosX(80);
						SetCursorPosY(280);
						Checkbox(e("Hit Sound"), &config.Includes.Misc.hitsound);
						SetCursorPosX(80);
						SetCursorPosY(295);
						Checkbox(e("Shoot in debug"), &config.Includes.Misc.shootindebug);
						SetCursorPosX(80);
						SetCursorPosY(310);
						Checkbox(e("No Animation"), &config.Includes.Misc.noanimat);
					}
					draw->AddRectFilled({ pos.x + 234,pos.y + 35 }, { pos.x + 440, pos.y + 387 }, ImColor(12, 12, 12, 255), 0, 0);
					draw->AddRect({ pos.x + 234,pos.y + 35 }, { pos.x + 440, pos.y + 387 }, ImColor(3, 3, 3, 235), 0, 0, 1.3f);
					draw->AddRect({ pos.x + 233,pos.y + 34 }, { pos.x + 441, pos.y + 388 }, ImColor(20, 20, 20, 255), 0, 0, .8f);
					draw->AddText({ pos.x + 289 ,pos.y + 40 }, ImColor(255, 255, 255), "Miscellaneous");
					{
						SetCursorPosX(300);
						SetCursorPosY(80);
						Text(e("FlyHack Key"));
						SetCursorPosX(290);
						SetCursorPosY(109);
						flyhack::FlykeyButton(config.Includes.Misc.flyhackkey, flyhack::ChangeKey, flyhack::keystatus0);
						SetCursorPosX(240);
						SetCursorPosY(145);
						SliderFloat(e("Fov Changer"), &config.Includes.Visual.FovChanger, .00f, 135.00f, "%.2f");
						SetCursorPosX(240);
						SetCursorPosY(175);
						SliderFloat(e("recoil X"), &config.Includes.Misc.xrecoli, 0, 1, "%.2f");
						SetCursorPosX(240);
						SetCursorPosY(195);
						SliderFloat(e("recoil Y"), &config.Includes.Misc.yrecoli, 0, 1, "%.2f");
					}
				}
			}

			if (config.Includes.Setiings.m_bCurrentTab == 3)
			{
				draw->AddRectFilled({ pos.x + 15,pos.y + 35 }, { pos.x + 220, pos.y + 387 }, ImColor(12, 12, 12, 255), 0, 0);
				draw->AddRect({ pos.x + 15,pos.y + 35 }, { pos.x + 220, pos.y + 387 }, ImColor(3, 3, 3, 235), 0, 0, 1.3f);
				draw->AddRect({ pos.x + 14,pos.y + 34 }, { pos.x + 221, pos.y + 388 }, ImColor(20, 20, 20, 255), 0, 0, .8f);
				draw->AddText({ pos.x + 89 ,pos.y + 40 }, ImColor(255, 255, 255), "Player Visual");
				{
					SetCursorPosX(80);
					SetCursorPosY(80);
					Checkbox(e("Box"), &config.Includes.Visual.box);
					SetCursorPosX(80);
					SetCursorPosY(95);
					Checkbox(e("health"), &config.Includes.Visual.health);
					SetCursorPosX(80);
					SetCursorPosY(110);
					Checkbox(e("name"), &config.Includes.Visual.nameesp);
					SetCursorPosX(80);
					SetCursorPosY(125);
					Checkbox(e("distance"), &config.Includes.Visual.distance);
					SetCursorPosX(80);
					SetCursorPosY(140);
					Checkbox(e("skeleton"), &config.Includes.Visual.skelly);
					SetCursorPosX(80);
					SetCursorPosY(165);
					Checkbox(e("belt"), &config.Includes.Visual.belt_esp);
					SetCursorPosX(80);
					SetCursorPosY(180);
					Checkbox(e("held iteam"), &config.Includes.Visual.helditem_esp);
					SetCursorPosX(80);
					SetCursorPosY(195);
					Checkbox(e("reload bar"), &config.Includes.Visual.reloadindicator);
					SetCursorPosX(80);
					SetCursorPosY(210);
					Checkbox(e("Bullet Tracer"), &config.Includes.Misc.bullettracer);
					SetCursorPosX(80);
					SetCursorPosY(235);
					Checkbox(e("flyhack bar"), &config.Includes.Visual.flyhackbar);
				}
				draw->AddRectFilled({ pos.x + 234,pos.y + 35 }, { pos.x + 440, pos.y + 387 }, ImColor(12, 12, 12, 255), 0, 0);
				draw->AddRect({ pos.x + 234,pos.y + 35 }, { pos.x + 440, pos.y + 387 }, ImColor(3, 3, 3, 235), 0, 0, 1.3f);
				draw->AddRect({ pos.x + 233,pos.y + 34 }, { pos.x + 441, pos.y + 388 }, ImColor(20, 20, 20, 255), 0, 0, .8f);
				draw->AddText({ pos.x + 289 ,pos.y + 40 }, ImColor(255, 255, 255), "Chams");
				{
					SetCursorPosX(240);
					SetCursorPosY(80);
					SliderFloat(e("esp Distance"), &config.Includes.Visual.PlayerDistance, 25.00f, 250.00f, "%.2f");
					SetCursorPosX(290);
					SetCursorPosY(110);
					if (BeginCombo("Chams", config.Includes.Visual.Chams[config.Includes.Visual.selectedChams])) {
						for (int i = 0; i < IM_ARRAYSIZE(config.Includes.Visual.Chams); i++) {
							bool isSelected = (config.Includes.Visual.selectedChams == i);
							if (ImGui::Selectable(config.Includes.Visual.Chams[i], isSelected))
								config.Includes.Visual.selectedChams = i;
							if (isSelected)
								ImGui::SetItemDefaultFocus();
						}
						ImGui::EndCombo();
					}
					SetCursorPosX(290);
					SetCursorPosY(180);
					if (BeginCombo("Clothing", config.Includes.Visual.ClothingChams[config.Includes.Visual.selectedClothingChams])) {
						for (int i = 0; i < IM_ARRAYSIZE(config.Includes.Visual.ClothingChams); i++) {
							bool isSelected = (config.Includes.Visual.selectedClothingChams == i);
							if (ImGui::Selectable(config.Includes.Visual.ClothingChams[i], isSelected))
								config.Includes.Visual.selectedClothingChams = i;
							if (isSelected)
								ImGui::SetItemDefaultFocus();
						}
						ImGui::EndCombo();
					}
					SetCursorPosX(290);
					SetCursorPosY(250);
					if (BeginCombo("Weapon", config.Includes.Visual.WeaponChams[config.Includes.Visual.selectedWeaponChams])) {
						for (int i = 0; i < IM_ARRAYSIZE(config.Includes.Visual.WeaponChams); i++) {
							bool isSelected = (config.Includes.Visual.selectedWeaponChams == i);
							if (ImGui::Selectable(config.Includes.Visual.WeaponChams[i], isSelected))
								config.Includes.Visual.selectedWeaponChams = i;
							if (isSelected)
								ImGui::SetItemDefaultFocus();
						}
						ImGui::EndCombo();
					}
				}
			}

			if (config.Includes.Setiings.m_bCurrentTab == 4)
			{

			}

			if (config.Includes.Setiings.m_bCurrentTab == 5)
			{

			}

			if (config.Includes.Setiings.m_bCurrentTab == 6)
			{
				if (SettingsSystem_Tab == 0)
				{
					draw->AddRectFilled({ pos.x + 15,pos.y + 35 }, { pos.x + 220, pos.y + 387 }, ImColor(12, 12, 12, 255), 0, 0);
					draw->AddRect({ pos.x + 15,pos.y + 35 }, { pos.x + 220, pos.y + 387 }, ImColor(3, 3, 3, 235), 0, 0, 1.3f);
					draw->AddRect({ pos.x + 14,pos.y + 34 }, { pos.x + 221, pos.y + 388 }, ImColor(20, 20, 20, 255), 0, 0, .8f);
					draw->AddText({ pos.x + 89 ,pos.y + 40 }, ImColor(255, 255, 255), "Config");
					{
						SetCursorPosX(10);
						SetCursorPosY(60);
						if (ListBox("##Includes::config_list", &current_config, [](void* data, int idx, const char** out_text)
							{
								auto& vector = *(std::vector<std::string> *)(data);
								*out_text = vector[idx].c_str();
								return true;
							}, &config_items, (int)(config_items.size()), 5) && current_config != -1) strcpy_s(buffer, config_items[current_config].c_str());
					}
					draw->AddRectFilled({ pos.x + 234,pos.y + 35 }, { pos.x + 440, pos.y + 387 }, ImColor(12, 12, 12, 255), 0, 0);
					draw->AddRect({ pos.x + 234,pos.y + 35 }, { pos.x + 440, pos.y + 387 }, ImColor(3, 3, 3, 235), 0, 0, 1.3f);
					draw->AddRect({ pos.x + 233,pos.y + 34 }, { pos.x + 441, pos.y + 388 }, ImColor(20, 20, 20, 255), 0, 0, .8f);
					draw->AddText({ pos.x + 289 ,pos.y + 40 }, ImColor(255, 255, 255), "Config");
					{
						SetCursorPosX(240);
						SetCursorPosY(80);
						if (ImGui::Button("Reset"))
							config.reset();
						if (current_config > -1)
						{
							SameLine();
							if (ImGui::Button("Save"))
								config.save(current_config);

							ImGui::SameLine();
							if (ImGui::Button("Load"))
								config.load(current_config);
						}
					}
				}
			}
		}
		ImGui::End ( );
	}

	auto create_window ( std::function<void ( )> callback ) -> bool
	{
		const auto window = FindWindow(e("MedalOverlayClass"), e("MedalOverlay"));
		if ( !window )
			return false;

		const auto window_hwnd = FindWindow ( NULL, e ( "Rust" ) );
		if ( !window_hwnd )
			return false;

		ShowWindow ( window, SW_SHOW );
		UpdateWindow ( window );

		if ( !dx9::create_device ( window, config.Includes.Setiings.width, config.Includes.Setiings.height ) )
			return false;

		ImGui::CreateContext ( );
		auto& io = ImGui::GetIO ( );
		ImGuiStyle* style = &ImGui::GetStyle();
		ImFontConfig font_config;
		io.IniFilename = nullptr;
		font_config.PixelSnapH = false;
		font_config.OversampleH = 5;
		font_config.OversampleV = 5;
		font_config.RasterizerMultiply = 1.2f;

		static const ImWchar ranges[] =
		{
			0x0020, 0x00FF, // Basic Latin + Latin Supplement
			0x0400, 0x052F, // Cyrillic + Cyrillic Supplement
			0x2DE0, 0x2DFF, // Cyrillic Extended-A
			0xA640, 0xA69F, // Cyrillic Extended-B
			0xE000, 0xE226, // icons
			0,
		};

		font_config.GlyphRanges = ranges;

		io.Fonts->AddFontFromFileTTF("C:\\Windows\\Fonts\\verdana.ttf", 14.0f, &font_config, ranges);
		mine = io.Fonts->AddFontFromMemoryTTF(MC, sizeof(MC), 18.f, &font_config, ranges);
		mine1 = io.Fonts->AddFontFromMemoryTTF(MC, sizeof(MC), 15.f, &font_config, ranges);

		ImGui_ImplWin32_Init ( window );
		ImGui_ImplDX9_Init ( dx9::p_device );

		dx9::g_d3d->Release ( );

		SetWindowPos ( window, 0, 0, 0, config.Includes.Setiings.width, config.Includes.Setiings.height, 0 );

		auto exstyle = GetWindowLongA ( window, GWL_EXSTYLE );
		exstyle &= ~WS_EX_NOACTIVATE;
		SetWindowLongA ( window, GWL_EXSTYLE, exstyle );

		auto msg = MSG{};
		while ( true )
		{
			if ( PeekMessage ( &msg, 0, 0U, 0U, PM_REMOVE ) )
			{
				TranslateMessage ( &msg );
				DispatchMessage ( &msg );
			}

			if ( GetForegroundWindow ( ) == window_hwnd )
			{
				SetWindowPos ( window, GetWindow ( window_hwnd, GW_HWNDPREV ), 0, 0, config.Includes.Setiings.width, config.Includes.Setiings.height, SWP_NOMOVE | SWP_NOSIZE );
			}

			if ( config.Includes.Setiings.showing )
			{
				POINT p;
				GetCursorPos ( &p );
				io.MousePos.x = p.x;
				io.MousePos.y = p.y;

				if ( GetAsyncKeyState ( VK_LBUTTON ) )
				{
					io.MouseDown[ 0 ] = true;
					io.MouseClicked[ 0 ] = true;
					io.MouseClickedPos[ 0 ].x = io.MousePos.x;
					io.MouseClickedPos[ 0 ].x = io.MousePos.y;
				}
				else io.MouseDown[ 0 ] = false;
			}

			if ( GetAsyncKeyState ( VK_INSERT ) & 1 )
				config.Includes.Setiings.showing ^= true;

			dx9::begin_scene ( );

			auto foreground = ImGui::GetForegroundDrawList ( );
			auto background = ImGui::GetBackgroundDrawList ( );

			//draw visuals - do prefabs here too
			{
				visuals::draw_loop ( );
			}

			if ( config.Includes.Setiings.showing ) callback ( ); // menu rendering

			dx9::end_scene ( );

			std::this_thread::sleep_for ( std::chrono::milliseconds ( 1 ) );
		}

		ImGui_ImplDX9_Shutdown ( );
		ImGui_ImplWin32_Shutdown ( );
		ImGui::DestroyContext ( );

		DestroyWindow ( window );
	}
}