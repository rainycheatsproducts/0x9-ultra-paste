#pragma once
#include <cstdint>
#include <algorithm>
#include <iostream>
#include <iomanip>
#include <map>
#define IMGUI_DEFINE_MATH_OPERATORS
#include "../../ui/imgui.h"
#include "../../ui/imgui_internal.h"

using namespace ImGui;

namespace p_interface {
    bool tab(const char* label, bool selected);
    bool subtab(const char* label, bool selected);
}
