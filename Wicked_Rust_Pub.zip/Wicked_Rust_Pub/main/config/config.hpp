#pragma once
#include <thread>
#include <random>
#include <d3d9.h>
#include <dinput.h>
#include <mciapi.h>
#include <strsafe.h> 
#include <Uxtheme.h>
#include <stdio.h>
#include <array>
#include <Psapi.h>
#include <dwmapi.h>
#include <algorithm>
#include <winternl.h>
#include <stdexcept>
#include <ctime>
#include <time.h>
#include <functional>
#include <cctype>
#include <iomanip>
#include <sstream>
#include <regex>
#include <ProcessSnapshot.h>
#include <ShlObj_core.h>
#include <mutex>
#include <tchar.h>
#include <tlhelp32.h>
#include <filesystem>
#include <iostream>
#include <tchar.h>
#include <string.h>
#include <urlmon.h>
#include <Mmsystem.h>
#include <Windows.h>
#include <mmstream.h>
#include <chrono>
#include <fstream>
#include <wingdi.h>
#include <sapi.h>
#include <d3dx9.h>
#include <d3dx9tex.h>
#include "archivex.hpp"

#pragma comment(lib,"d3d9.lib")
#pragma comment(lib, "d3dx9.lib")
#pragma comment(lib, "shell32.lib")
#pragma comment(lib, "winmm.lib")
#pragma comment(lib, "ntdll.lib")
#pragma comment(lib,"urlmon.lib")

const char* const key_names[] =
{
	"Unknown",
	"VK_LBUTTON",
	"RBUTTON",
	"CANCEL",
	"MBUTTON",
	"XBUTTON1",
	"XBUTTON2",
	"Unknown",
	"BACK",
	"TAB",
	"Unknown",
	"Unknown",
	"CLEAR",
	"RETURN",
	"Unknown",
	"Unknown",
	"SHIFT",
	"CONTROL",
	"MENU",
	"PAUSE",
	"CAPITAL",
	"KANA",
	"Unknown",
	"JUNJA",
	"FINAL",
	"KANJI",
	"Unknown",
	"ESCAPE",
	"CONVERT",
	"NONCONVERT",
	"ACCEPT",
	"MODECHANGE",
	"SPACE",
	"PRIOR",
	"NEXT",
	"END",
	"HOME",
	"LEFT",
	"UP",
	"RIGHT",
	"DOWN",
	"SELECT",
	"PRINT",
	"EXECUTE",
	"SNAPSHOT",
	"INSERT",
	"DELETE",
	"HELP",
	"0",
	"1",
	"2",
	"3",
	"4",
	"5",
	"6",
	"7",
	"8",
	"9",
	"Unknown",
	"Unknown",
	"Unknown",
	"Unknown",
	"Unknown",
	"Unknown",
	"Unknown",
	"A",
	"B",
	"C",
	"D",
	"E",
	"F",
	"G",
	"H",
	"I",
	"J",
	"K",
	"L",
	"M",
	"N",
	"O",
	"P",
	"Q",
	"R",
	"S",
	"T",
	"U",
	"V",
	"W",
	"X",
	"Y",
	"Z",
	"LWIN",
	"RWIN",
	"APPS",
	"Unknown",
	"SLEEP",
	"NUMPAD0",
	"NUMPAD1",
	"NUMPAD2",
	"NUMPAD3",
	"NUMPAD4",
	"NUMPAD5",
	"NUMPAD6",
	"NUMPAD7",
	"NUMPAD8",
	"NUMPAD9",
	"MULTIPLY",
	"ADD",
	"SEPARATOR",
	"SUBTRACT",
	"DECIMAL",
	"DIVIDE",
	"F1",
	"F2",
	"F3",
	"F4",
	"F5",
	"F6",
	"F7",
	"F8",
	"F9",
	"F10",
	"F11",
	"F12",
	"F13",
	"F14",
	"F15",
	"F16",
	"F17",
	"F18",
	"F19",
	"F20",
	"F21",
	"F22",
	"F23",
	"F24",
	"Unknown",
	"Unknown",
	"Unknown",
	"Unknown",
	"Unknown",
	"Unknown",
	"Unknown",
	"Unknown",
	"NUMLOCK",
	"SCROLL",
	"OEM_NEC_EQUAL",
	"OEM_FJ_MASSHOU",
	"OEM_FJ_TOUROKU",
	"OEM_FJ_LOYA",
	"OEM_FJ_ROYA",
	"Unknown",
	"Unknown",
	"Unknown",
	"Unknown",
	"Unknown",
	"Unknown",
	"Unknown",
	"Unknown",
	"Unknown",
	"LSHIFT",
	"RSHIFT",
	"LCONTROL",
	"RCONTROL",
	"LMENU",
	"RMENU"
};

class c_keybind
{
public:
	inline static const char* type_char[ 3 ]
	{
		"Toggle",
		"Hold",
		"Always"
	};

	static enum keybind_type : int
	{
		TOGGLE,
		HOLD,
		ALWAYS
	};

	int key = 0;
	int type = HOLD;
	const char* name = "none";

	bool enabled = false;
	bool waiting_for_input = false;

	c_keybind ( const char* _name )
	{
		this->name = _name;
	}

	auto get_key_name ( ) -> const char*
	{
		if ( !this->key )
			return "None";

		return key_names[ this->key ];
	}

	auto get_name ( ) -> const char*
	{
		return this->name;
	}

	auto get_type ( ) -> const char*
	{
		switch ( this->type )
		{
		case TOGGLE:
			return "Toggle";
			break;
		case HOLD:
			return "Hold";
			break;
		case ALWAYS:
			return "Always";
			break;
		default:
			return "None";
		}
	}

	auto get_key ( ) -> bool
	{
		switch ( this->type )
		{
		case TOGGLE:
			if ( GetAsyncKeyState ( this->key ) & 1 )
				this->enabled = !this->enabled;
			break;
		case HOLD:
			this->enabled = GetAsyncKeyState ( this->key );
			break;
		case ALWAYS:
			this->enabled = true;
			break;
		}
		return this->enabled;
	}
};

class c_config
{
private:
	std::filesystem::path path;
	std::vector<std::string> configs;

public:
	void run();
	void run2();
	void load(size_t id);
	void save(size_t id) const;
	void add(std::string name);
	void remove(size_t id);
	void rename(size_t item, std::string new_name);
	void reset();

	constexpr auto& get_configs() {
		return configs;
	};
	constexpr auto& get_path() {
		return path;
	};

	struct
	{

		struct Aimbot
		{
			bool enableaim{ false };
			bool memoryaim{ false };
			bool Silentaim{ false };
			int  selectedAimtypeIndex = { 0 };
			int keybindaim;
			int LongneckUp;
			int LongNeckLeft;
			int LongNeckRight;
			int LongNeckactivare;
		} Aimbot;

		struct Misc
		{
			bool automatic = { false };//make guns shoot automatic
			bool nosway = { false };// no sway
			float xrecoli{ 1 };// x recoli slider
			float yrecoli{ 1 };// y recoli slider
			bool instantbow{ false };//shoot bow fast
			bool insteoka{ false };//shoot eoka no tap
			bool nospread{ false };// no spread
			bool thickbullet{ false };//thicc bullet
			bool hitsound{ false }; //makes a sound when you hit a player
			bool bullettracer{ false };// draw bullet tracer
			bool norecoli{ false };
			bool shootindebug{ false };
			int flyhackkey;
			bool flyhack{ false };
			bool noanimat{ false };
		} Misc;


		struct Movement
		{
			bool spiderman{ false };//spyderman
			bool infinitejump{ false };//inf jump
			bool holditemswhilemounted{ false };//hold guns while mounted
			bool omnisprint{ false };// runs back and any angle
		} Movement;

		struct Visual
		{
			float PlayerDistance = {120};
			float NpcDistance = { 120 };
			float PrefabDistance = { 120 };
			bool health{ false };//health esp
			bool box{ false };//box esp
			bool skelly{ false };// skeleton esp
			bool reloadindicator{ false };//reload indicator
			bool nameesp{ false };// name esp
			bool helditem_esp{ false };//held iteam esp
			bool belt_esp{ false };// belt esp
			bool distance{ false };// distance esp
			bool metalore{ false };// metalore esp
			bool sulfurore{ false };// sulfurore esp
			bool stoneore{ false };// stoneore esp
			bool hemp{ false };// hemp esp
			bool wood{ false };// wood esp
			bool mushroom{ false };// mushroom esp
			bool potato{ false };// potato esp
			bool bradley{ false };// bradley esp
			bool bradleycrate{ false };// bradleycrate esp
			bool hackablecrate{ false };// hackablecrate esp
			bool normalcrate{ false };// normalcrate esp
			bool elitecrate{ false };// elitecrate esp
			bool minicopter{ false };// minicopter esp
			bool samsite{ false };// samsite esp
			bool corpsebackpack{ false };// corpsebackpack esp
			bool beartrap{ false };// beartrap esp
			bool guntrap{ false };// guntrap esp
			bool flameturret{ false };// flameturret esp
			bool landmine{ false };// landmine esp
			bool autoturret{ false };// autoturret esp
			bool supplydrop{ false };// supplydrop esp
			bool woodenbox{ false };// normalcrate esp
			bool cupboard{ false };// cupboard esp
			bool smallstash{ false };// small stash esp
			bool corpse{ false }; //corpse esp
			bool helicrate{ false }; //helicrate esp
			bool flyhackbar{ false };//fly hack bar
			const char* Chams[9] = { "None", "Flat Red", "Glow Red", "Glow Green","punking glow","plant","blue/red","ore coal","iron"};
			int selectedChams = { 0 };
			const char* ClothingChams[9] = { "None", "Flat Red", "Glow Red", "Glow Green","punking glow","plant","blue/red","ore coal","iron" };
			int selectedClothingChams = { 0 };
			const char* WeaponChams[7] = { "None", "Flat Red", "Watter","punking glow","plant","ore coal","iron" };
			int selectedWeaponChams = { 0 };
			float FovChanger = { 120 };
			bool NiceSky = { true };
		} Visual;

		struct Setiings
		{
			float fov = { 60.f };
			int m_bCurrentTab{ 0 };
			int width;
			int height;
			bool showing{ true };
			bool particluse{ true };
			float fly_height{ 0.f };
			float fly_direction{ 0.f };
			float m_height{ 0.f };
			float m_direction{ 0.f };
		} Setiings;


	}Includes;



}; inline auto config = c_config ( );