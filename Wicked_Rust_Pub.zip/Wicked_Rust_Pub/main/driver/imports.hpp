#pragma once
#include <vector>
#include <fstream>
#include <filesystem>
#include <map>
//imgui
#include "../../ui/imgui.h"
#include "../../ui/imgui_internal.h"
#include "../../ui/imgui_impl_dx9.h"
#include "../../ui/imgui_impl_win32.h"
//config - includes
#include "../config/config.hpp"
//other
#include "../cheat/system/math.hpp"
#include "string/estr.hpp"
#include "memory.hpp"
#include "../cheat/system/offsets.hpp"
using namespace Offsets;
mem driver(utils::globals::process_id);

//systems
#include "../cheat/system/systems.hpp"

//il2cpp header
#define declare_member(type, name, shift)														\
	auto name ( ) -> type																		\
	{																							\
		return driver.read<type>( reinterpret_cast<std::uintptr_t>( this ) + shift );			\
	}																							\
																								\
	auto set_##name( type name ) -> void														\
	{																							\
		driver.write<type>( reinterpret_cast< std::uintptr_t >( this ) + shift, name );			\
	}	
//classes
#include "../cheat/class/c_time.h"
#include "../cheat/class/c_rigid_body.h"
#include "../cheat/class/c_player_belt.h"
#include "../cheat/class/c_capsule_collider.h"
#include "../cheat/class/c_player_eyes.h"
#include "../cheat/class/c_player_tick.h"
#include "../cheat/class/c_base_mountable.h"
#include "../cheat/class/c_model_state.h"
#include "../cheat/class/c_base_collision.h"
#include "../cheat/class/c_base_movement.h"
#include "../cheat/class/c_input_message.h"
#include "../cheat/class/c_input_state.h"
#include "../cheat/class/c_player_input.h"
#include "../cheat/class/c_skin_set.h"
#include "../cheat/class/c_skinset_collection.h"
#include "../cheat/class/c_player_model.h"
#include "../cheat/class/c_convar_graphics.h"
#include "../cheat/class/c_admin.h"
#include "../cheat/class/c_convar_admin.h"
#include "../cheat/class/c_convar_client.h"
#include "../cheat/class/c_transform.h"
#include "../cheat/class/c_model.h"
#include "../cheat/class/c_base_entity.h"
#include "../cheat/class/c_base_networkable.h"
#include "../cheat/class/c_base_combat_entity.h"
#include "../cheat/class/c_recoil_properties.h"
#include "../cheat/class/c_item_definition.h"
#include "../cheat/class/c_tod_scattering.h"
#include "../cheat/class/c_tod_components.h"
#include "../cheat/class/c_tod_sky.h"
#include "../cheat/class/c_skin_type.h"
#include "../cheat/class/c_groups.h"
#include "../cheat/class/c_skinnable.h"
#include "../cheat/class/c_ammo_definition.h"
#include "../cheat/class/c_magazine.h"
#include "../cheat/class/c_item_projectile_mod.h"
#include "../cheat/class/c_weapon_bob.h"
#include "../cheat/class/c_weapon_sway.h"
#include "../cheat/class/c_weapon_punch.h"
#include "../cheat/class/c_weapon_lower.h"
#include "../cheat/class/c_weapon_view_model.h"
#include "../cheat/class/c_view_model.h"
#include "../cheat/class/c_held_item.h"
#include "../cheat/class/c_item.h"
#include "../cheat/class/c_item_list.h"
#include "../cheat/class/c_item_container.h"
#include "../cheat/class/c_player_inventory.h"
#include "../cheat/class/c_hit_test.h"
#include "../cheat/class/c_projectile.h"
#include "../cheat/class/c_base_player.h"
#include "../cheat/class/c_camera.h"
#include "../cheat/class/c_object_class.h"
#include "../cheat/class/c_object.h"
#include "../cheat/class/c_unity.h"

//main
#include "../cheat/feature/enityloop/drawing.hpp"
#include "../cheat/feature/enityloop/entityloop.hpp"
#include "../cheat/feature/aimbot.hpp"
#include "../cheat/feature/localplayer.hpp"
#include "../cheat/feature/visuals.hpp"
#include "../menu/window.hpp"