#pragma once
#include <vector>
#include <Windows.h>
#include <functional>
#include <string>
#include "../string/estr.hpp"

namespace fptr_data
{
	constexpr std::uint64_t static_identifier = 0xBADC0DE;

	enum class kernel_opr : uint32_t
	{
		read = 1,
		write,
		get_process_module,
		get_process_base,

		unhook_driver,


		alloc,
		free,
		protect
	};

	enum class kernel_err : std::uint16_t
	{
		invalid_process = 2,
		check_fail,
		no_operation,
		invalid_data,

		no_error = 0,
		unset_err = 1
	};

	struct kernel_com
	{
		bool success;
		kernel_err error;

		std::uint32_t target_pid;
		std::uint32_t user_pid;

		std::uintptr_t address;
		std::uintptr_t buffer;

		union
		{
			std::size_t size;
			const char* name;
		};

		std::size_t transfer;
	};
}

class mem
{
public:
	std::uint32_t pid;
public:
	mem(int PID)
		: pid(PID)
	{
		pid = PID;
	}

	bool init();
	void unload();

	std::uintptr_t get_process_module(const char* name);
	std::uintptr_t get_process_base(std::uint32_t _pid = 0);

	bool read_buffer(std::uintptr_t addr, std::uint8_t* buffer, std::size_t size, std::size_t* transfer = nullptr);
	bool write_buffer(std::uintptr_t addr, std::uint8_t* buffer, std::size_t size, std::size_t* transfer = nullptr);

	template<typename T>
	auto read(std::uintptr_t addr) -> T
	{
		T val;
		if (!this->read_buffer(addr, (std::uint8_t*)&val, sizeof(T))) memset((void*)&val, 0, sizeof(val));
		return val;
	}

	template<typename T>
	auto write(std::uintptr_t addr, T val) -> void
	{
		this->write_buffer(addr, (std::uint8_t*)&val, sizeof(T));
	}

	template <typename T>
	auto read_chain(std::uintptr_t address, std::vector<std::uintptr_t> chain) -> T
	{
		std::uintptr_t current = address;
		for (int i = 0; i < chain.size() - 1; i++) current = this->read<std::uintptr_t>(current + chain[i]);
		return this->read<T>(current + chain[chain.size() - 1]);
	}

	auto read_string(std::uintptr_t addr) -> std::string
	{
		char buffer[128];
		if (this->read_buffer(addr, (std::uint8_t*)&buffer, sizeof(buffer))) return std::string(buffer);
		else return e("None");
	}

	auto read_wstring(std::uintptr_t addr) -> std::wstring
	{
		wchar_t buffer[128];
		if (this->read_buffer(addr, (std::uint8_t*)&buffer, sizeof(buffer))) return std::wstring(buffer, wcslen(buffer));
		else return e(L"None");
	}
	auto get_component(std::uintptr_t game_object, std::string component_name) -> std::uintptr_t
	{
		if (!game_object) return NULL;

		auto component_list = read<std::uintptr_t>(game_object + 0x30);
		for (auto idx{ 0 }; idx < 60; idx++)
		{
			auto component = read<std::uintptr_t>(component_list + (0x10 * idx + 0x8));
			if (!component) continue;

			auto component_base = read<std::uintptr_t>(component + 0x28);
			if (!component_base) continue;

			auto component_name = read_string(component_base + 0x10);
			if (component_name.empty()) continue;

			if (component_name.find(component_name) != std::string::npos) return component_base;
		}
		return NULL;
	}


	std::uintptr_t alloc(std::uintptr_t addr, std::size_t size, std::uint32_t alloc_flags, std::uint32_t protection);
	void free(std::uintptr_t addr);
	void protect(std::uintptr_t addr, std::size_t size, std::uint32_t protection);
public:
	std::uintptr_t game_assembly;
	std::uintptr_t unity_player;
};