#include <Windows.h>
#include <iostream>
#include "driver.hpp"

typedef __int64(__fastcall* pfunc_hk_t)(__int64 a1, unsigned __int64 a2, unsigned __int64 a3, unsigned int a4, int a5);;
pfunc_hk_t pHookFunc = (pfunc_hk_t)NULL;

template<bool debug>
auto invoke_driver(fptr_data::kernel_com* com, fptr_data::kernel_opr op) -> bool
{
	if (!pHookFunc) return false;

	com->error = fptr_data::kernel_err::unset_err;
	if (!pHookFunc((std::uintptr_t)com, 0, fptr_data::static_identifier, (std::int32_t)op, 2) &&
		com->error == fptr_data::kernel_err::unset_err)
	{
		return false;
	}

	if (com->success) return true && com->error == fptr_data::kernel_err::no_error;
	if (!debug) return false;

	switch (com->error)
	{
	case fptr_data::kernel_err::check_fail:
	{
		//printf ( ( "Security check failure.\n" ) );
		break;
	}
	case fptr_data::kernel_err::invalid_data:
	{
		//printf ( ( "Invalid data.\n" ) );
		break;
	}
	case fptr_data::kernel_err::invalid_process:
	{
		//printf ( ( "Invalid process.\n" ) );
		break;
	}
	case fptr_data::kernel_err::no_operation:
	{
		//printf ( ( "Invalid funciton operation sent to driver.\n" ) );
		break;
	}
	}
	return false;
}

auto ensure_dll_load() -> HMODULE
{
#define LOAD_DLL(str) LoadLibrary((str))
	LOAD_DLL(e("user32.dll"));

#undef LOAD_DLL
	return LoadLibrary(e("win32u.dll"));
}

auto mem::init() -> bool
{
	if (!pHookFunc)
	{
		HMODULE hDll = GetModuleHandle(e("win32u.dll"));
		if (!hDll)
		{
			hDll = ensure_dll_load();
			if (!hDll) return false;
		}

		pHookFunc = (pfunc_hk_t)GetProcAddress(hDll, e("NtGdiPolyPolyDraw"));
		if (!pHookFunc)
		{
			pHookFunc = (pfunc_hk_t)NULL;
			return false;
		}
	}

	if (get_process_base(GetCurrentProcessId()) != (std::uintptr_t)GetModuleHandle(NULL)) return false;

	return true;
}

auto mem::unload() -> void
{
	fptr_data::kernel_com com{};
	invoke_driver<true>(&com, fptr_data::kernel_opr::unhook_driver);
}

auto mem::get_process_module(const char* name) -> std::uintptr_t
{
	fptr_data::kernel_com com{};
	com.target_pid = this->pid;
	com.name = name;

	if (!invoke_driver<true>(&com, fptr_data::kernel_opr::get_process_module)) return 0;

	return com.buffer;
}

auto mem::get_process_base(std::uint32_t _pid) -> std::uintptr_t
{
	fptr_data::kernel_com com{};
	com.target_pid = _pid ? _pid : this->pid;

	if (invoke_driver<true>(&com, fptr_data::kernel_opr::get_process_base)) return com.buffer;

	return 0;
}

auto mem::read_buffer(std::uintptr_t addr, std::uint8_t* buffer, std::size_t size, std::size_t* transfer) -> bool
{
	fptr_data::kernel_com com{};
	com.target_pid = this->pid;
	com.user_pid = GetCurrentProcessId();

	com.address = addr;
	com.buffer = (std::uintptr_t)buffer;
	com.size = size;

	if (!invoke_driver<true>(&com, fptr_data::kernel_opr::read)) return false;

	if (transfer) *transfer = com.transfer;

	return true;
}

auto mem::write_buffer(std::uintptr_t addr, std::uint8_t* buffer, std::size_t size, std::size_t* transfer) -> bool
{
	fptr_data::kernel_com com{};
	com.target_pid = this->pid;
	com.user_pid = GetCurrentProcessId();

	com.address = addr;
	com.buffer = (std::uintptr_t)buffer;
	com.size = size;

	if (!invoke_driver<true>(&com, fptr_data::kernel_opr::write)) return false;

	if (transfer) *transfer = com.transfer;

	return true;
}

auto mem::alloc(std::uintptr_t addr, std::size_t size, std::uint32_t alloc_flags, std::uint32_t protection) -> std::uintptr_t
{
	fptr_data::kernel_com com{};
	com.target_pid = this->pid;

	com.address = addr;
	com.size = size;
	com.buffer = alloc_flags;
	com.user_pid = protection;

	invoke_driver<true>(&com, fptr_data::kernel_opr::alloc);

	return com.address;
}

auto mem::free(std::uintptr_t addr) -> void
{
	fptr_data::kernel_com com{};
	com.target_pid = this->pid;

	com.address = addr;

	invoke_driver<true>(&com, fptr_data::kernel_opr::free);
}

auto mem::protect(std::uintptr_t addr, std::size_t size, std::uint32_t protection) -> void
{
	fptr_data::kernel_com com{};
	com.target_pid = this->pid;

	com.address = addr;
	com.buffer = protection;
	com.size = size;

	invoke_driver<true>(&com, fptr_data::kernel_opr::protect);
}