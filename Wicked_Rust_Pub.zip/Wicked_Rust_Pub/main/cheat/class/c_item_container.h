#pragma once
#include "../../driver/imports.hpp"

class c_item_container
{
public:
    declare_member ( c_item_list*, item_list, 0x40 ); // public List<Item> itemList; // 
};