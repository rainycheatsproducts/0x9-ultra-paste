#pragma once
#include "../../driver/imports.hpp"

class c_base_collision
{
public:

public:
};