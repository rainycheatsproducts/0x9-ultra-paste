#pragma once
#include "../../driver/imports.hpp"

class c_tod_components
{
public:
	declare_member ( c_tod_scattering*, Scattering, 0x1A0 );
};