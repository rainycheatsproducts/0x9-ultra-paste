#pragma once
#include "../../driver/imports.hpp"

class c_input_message
{
public:
	declare_member ( geo::vec3_t, aimAngles, 0x14 );
};