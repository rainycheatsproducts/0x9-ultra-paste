#pragma once
#include "../../driver/imports.hpp"

class c_item_definition
{
public:

};