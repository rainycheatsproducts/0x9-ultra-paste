#pragma once
#include "../../driver/imports.hpp"

class c_item_projectile_mod
{
public:
	declare_member ( float, projectileSpread, Classes::ItemModProjectile::projectileSpread );
	declare_member ( float, projectileVelocitySpread, Classes::ItemModProjectile::projectileVelocitySpread );
};