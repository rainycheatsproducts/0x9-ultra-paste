#pragma once
#include "../../driver/imports.hpp"

class c_view_model
{
public:
	declare_member ( c_weapon_view_model*, instance, 0x28 );
};