#pragma once
#include "../../driver/imports.hpp"

class c_skinset_collection
{
public:
	declare_member ( systems::c_array<c_skin_set*>*, skinSet, 0x18 );
};