#pragma once
#include "../../driver/imports.hpp"

class c_player_eyes
{
public:
	declare_member ( geo::vec3_t, viewOffset, Classes::PlayerEyes::viewOffset );
	declare_member ( geo::vec3_t, headAnglesk__BackingField, Classes::PlayerEyes::headAnglesk__BackingField );
	declare_member ( geo::vec4_t, bodyRotationk__BackingField, Classes::PlayerEyes::bodyRotationk__BackingField );
public:

};