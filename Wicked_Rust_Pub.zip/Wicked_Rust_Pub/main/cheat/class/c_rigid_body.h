#pragma once
#include "../../driver/imports.hpp"

class c_rigid_body
{
public:

public:

};