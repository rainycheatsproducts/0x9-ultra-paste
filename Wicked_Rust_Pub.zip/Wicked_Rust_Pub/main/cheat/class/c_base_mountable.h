#pragma once
#include "../../driver/imports.hpp"

class c_base_mountable
{
public:
	declare_member ( bool, canWieldItems, Classes::BaseMountable::canWieldItems );
public:
};