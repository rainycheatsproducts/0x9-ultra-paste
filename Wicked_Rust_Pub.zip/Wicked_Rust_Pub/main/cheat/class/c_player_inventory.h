#pragma once
#include "../../driver/imports.hpp"

class c_player_inventory
{
public:
	declare_member ( c_item_container*, get_belt, 0x28 );
public:

};