#pragma once
#include "../../driver/imports.hpp"

class c_ammo_definition
{
public:
	declare_member ( int, ammo_id, 0x18 );
};