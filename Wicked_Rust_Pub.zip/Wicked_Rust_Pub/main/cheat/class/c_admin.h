#pragma once
#include "../../driver/imports.hpp"

class c_admin
{
public:
	declare_member ( float, adminTime, 0x0 );
};