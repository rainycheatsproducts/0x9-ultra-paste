#pragma once
#include "../../driver/imports.hpp"

class c_skin_type
{
public:
	declare_member ( std::uintptr_t, value, 0x10 );
};