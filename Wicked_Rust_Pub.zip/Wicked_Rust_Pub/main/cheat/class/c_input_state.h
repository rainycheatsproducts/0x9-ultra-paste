#pragma once
#include "../../driver/imports.hpp"

class c_input_state
{
public:
	declare_member ( c_input_message*, current, Classes::InputState::current );
};