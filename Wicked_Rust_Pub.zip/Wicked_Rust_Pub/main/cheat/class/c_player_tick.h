#pragma once
#include "../../driver/imports.hpp"

class c_player_tick
{
public:

public:

};