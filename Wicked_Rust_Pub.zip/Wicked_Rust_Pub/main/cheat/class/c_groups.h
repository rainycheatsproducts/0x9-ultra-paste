#pragma once
#include "../../driver/imports.hpp"

class c_groups
{
public:
	declare_member ( c_skin_type*, material, 0x18 );
};