#pragma once
#include "../../driver/imports.hpp"

auto flyhack_bar() -> void
{
	const auto grounded = rainy.player->movement()->grounded();
	auto position = rainy.player->playerModel()->position();
	if (position.is_empty()) return;
	static auto start = geo::vec3_t();
	if (!grounded && start.is_empty())
		start = position;
	else if (grounded)
	{
		start = geo::vec3_t(0.00f, 0.00f, 0.00f);
		config.Includes.Setiings.m_height = 0.00f;
		config.Includes.Setiings.m_direction = 0.00f;
	}
	else if (!start.is_empty())
	{
		config.Includes.Setiings.m_height = position.y - start.y;
		config.Includes.Setiings.m_direction = geo::vec2_t(position.x, position.z).distance({ start.x, start.z });
	}
}

auto get_rust_installation ( ) -> std::string
{
	LONG   lResult;
	HKEY   hKey;
	char   value[ 64 ];
	DWORD  value_length = 64;
	DWORD  dwType = REG_SZ;

	lResult = RegOpenKey ( HKEY_LOCAL_MACHINE, TEXT ( e ( "SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\Steam App 252490" ) ), &hKey );
	RegQueryValueExA ( hKey, e ( "InstallLocation" ), NULL, &dwType, ( LPBYTE ) &value, &value_length );

	RegCloseKey ( hKey );

	return value;
}

auto texture_bundle_path = get_rust_installation ( ) + e ( "\\Bundles\\items\\" );

class c_texture_cache
{
private:
	std::unordered_map<std::string, IDirect3DTexture9*> texture_cache{};

	auto create_texture ( LPDIRECT3DDEVICE9 device, std::string name ) -> IDirect3DTexture9*
	{
		auto image_path = texture_bundle_path + name; // todo: make path dynamic
		auto* tex = LPDIRECT3DTEXTURE9 ( );

		if ( D3DXCreateTextureFromFileA ( device, image_path.c_str ( ), &tex ) != D3D_OK )
			return nullptr;

		return tex;
	}
public:
	auto get_texture ( std::string item_name ) -> IDirect3DTexture9*
	{
		if ( texture_cache.find ( item_name ) != texture_cache.end ( ) )
			return texture_cache[ item_name ];

		auto texture = create_texture ( dx9::p_device, item_name + e ( ".png" ) );
		if ( !texture )
			return nullptr;

		texture_cache.emplace ( item_name, texture );
		return texture;
	}

}; inline c_texture_cache texture_cache;

namespace visuals
{
	auto black_color = geo::vec4_t{ 0, 0, 0, 255 };
	auto main_color = geo::vec4_t{ 146, 157, 223, 255.0f };
	auto draw_loop ( ) -> void
	{
		const auto gui = ImGui::GetBackgroundDrawList ( );
		geo::vec2_t size, bottom, top;
		const geo::vec2_t screen_center = { ( float ) config.Includes.Setiings.width / 2, ( float ) config.Includes.Setiings.height / 2 };

		uintptr_t TOD_Sky = driver.read<uintptr_t>(driver.game_assembly + Offsets::Vars::m_TodSky_c); // tod_sky_c*
		uintptr_t TOD_AimbientParameters = driver.read_chain<uintptr_t>(TOD_Sky, { 0xB8, 0x0, 0x10, 0x20, Offsets::Classes::TOD_Sky::Ambient });
		uintptr_t TOD_CloudParameters = driver.read_chain<uintptr_t>(TOD_Sky, { 0xB8, 0x0, 0x10, 0x20, Offsets::Classes::TOD_Sky::Clouds });
		uintptr_t TOD_NightParameters = driver.read_chain<uintptr_t>(TOD_Sky, { 0xB8, 0x0, 0x10, 0x20, Offsets::Classes::TOD_Sky::Night });
		uintptr_t TOD_StarParameters = driver.read_chain<uintptr_t>(TOD_Sky, { 0xB8, 0x0, 0x10, 0x20, Offsets::Classes::TOD_Sky::Stars });
		uintptr_t TOD_MoonParameters = driver.read_chain<uintptr_t>(TOD_Sky, { 0xB8, 0x0, 0x10, 0x20, Offsets::Classes::TOD_Sky::Moon });
		uintptr_t TOD_SunParameters = driver.read_chain<uintptr_t>(TOD_Sky, { 0xB8, 0x0, 0x10, 0x20, Offsets::Classes::TOD_Sky::Sun });
		uintptr_t TOD_DayParameters = driver.read_chain<uintptr_t>(TOD_Sky, { 0xB8, 0x0, 0x10, 0x20, Offsets::Classes::TOD_Sky::Day });
		if (config.Includes.Visual.NiceSky)
		{
			driver.write<float>(TOD_StarParameters + 0x10, 0.7f);//star size https://rust.dumps.host/?class=TOD_Sky
			driver.write<float>(TOD_StarParameters + 0x14, 1000.f);//star brightness
			driver.write<float>(TOD_MoonParameters + 0x1c, 0.08f);//halo size https://rust.dumps.host/?class=TOD_Sky
			driver.write<float>(TOD_MoonParameters + 0x20, 10.f);//halo brightness
			//Day Stuff
			driver.write<float>(TOD_DayParameters + Offsets::Classes::TOD_DayParameters::ReflectionMultiplier, 0.f);
			driver.write<float>(TOD_DayParameters + Offsets::Classes::TOD_DayParameters::ShadowStrength, 0.f);
			//Star Stuff
			driver.write<float>(TOD_StarParameters + Offsets::Classes::TOD_StarParameters::Brightness, 256.f);
			driver.write<float>(TOD_StarParameters + Offsets::Classes::TOD_StarParameters::Size, 0.5f);
			//Night Stuff
			driver.write<float>(TOD_NightParameters + Offsets::Classes::TOD_NightParameters::LightIntensity, 8.f);
			driver.write<float>(TOD_NightParameters + Offsets::Classes::TOD_NightParameters::AmbientMultiplier, 10.f);
		}

		{// fov cercle
			gui->AddCircle ( { screen_center.x, screen_center.y }, config.Includes.Setiings.fov, ImColor ( 255, 255, 255 ) );
		}
		{
			if (config.Includes.Visual.flyhackbar)
			{
				flyhack_bar();
				config.Includes.Setiings.fly_height = config.Includes.Setiings.m_height * 52.f;
				config.Includes.Setiings.fly_direction = config.Includes.Setiings.m_direction * 52.f;
				if (config.Includes.Setiings.fly_height >= 255.f) config.Includes.Setiings.fly_height = 0.f;
				if (config.Includes.Setiings.fly_height <= 0.f) config.Includes.Setiings.fly_height = 0.f;
				if (config.Includes.Setiings.fly_direction >= 255.f) config.Includes.Setiings.fly_direction = 0.f;
				if (config.Includes.Setiings.fly_direction <= 0.f) config.Includes.Setiings.fly_direction = 0.f;
				render::FilledRect(config.Includes.Setiings.width / 2.5, config.Includes.Setiings.height / 8, 250, 5, ImColor(56, 55, 55));
				render::FilledRect(config.Includes.Setiings.width / 2.5, config.Includes.Setiings.height / 8, config.Includes.Setiings.fly_height, 5, ImColor(146, 157, 223));
				render::FilledRect(config.Includes.Setiings.width / 2.5, config.Includes.Setiings.height / 8.35, 250, 5, ImColor(56, 55, 55));
				render::FilledRect(config.Includes.Setiings.width / 2.5, config.Includes.Setiings.height / 8.35, config.Includes.Setiings.fly_direction, 5, ImColor(146, 157, 223));
			}
		}
		const auto projectile = rainy.player->get_projectile ( );
		if ( projectile )
		{
			if ( utils::is_weapon ( projectile->shortname ( ) ) )
			{
				const auto held = projectile->heldEntity ( );
				if ( held )
				{

				}
			}
		}
		for (auto& prefab : rainy.prefab_list)
		{

		}
		for ( auto& player : rainy.player_list )
		{

			if ( !rainy.camera || !rainy.player ) continue;

			auto ply = player.cache.player;
			if ( !ply ) continue;

			auto distance = player.cache.distance;
			if ( !distance ) continue;

			auto player_model = ply->playerModel ( );
			if ( !player_model ) continue;

			auto position = player_model->position ( );
			if ( position.is_empty ( ) ) continue;

			if ( !rainy.camera->world_to_screen ( { position.x, position.y + 1.75f, position.z }, &top ) || !rainy.camera->world_to_screen ( { position.x, position.y - 0.25f, position.z }, &bottom ) ) continue;

			size = { ( bottom.y - top.y ) / ( float ) 1.8f, bottom.y - top.y };
			if ( size.is_empty ( ) ) continue;

			if (config.Includes.Visual.health)
			{
				//healthesp
				const auto health = ply->_health ( );
				const auto max_health = float ( ply->playerModel ( )->IsNpck__BackingField ( ) ? 150.00f : 100.00f );
				const auto color = render::quick::get_health_color ( health / max_health );
				gui->AddRectFilled ( { bottom.x + size.y / 4.00f + 6.05f, top.y }, { bottom.x + size.y / 4.00f + 2.00f, bottom.y + 3.00f }, ImColor{ 146, 157, 223 } );
				gui->AddRectFilled ( { bottom.x + size.y / 4.00f + 6.00f, top.y + ( size.y - ( size.y * float ( health / max_health ) ) ) }, { bottom.x + size.y / 4.00f + 2.00f, bottom.y + 3.00f }, ImColor((int)color.x, (int)color.y, (int)color.z, (int)255.00f));
			}
			
			//void playerinfo(BasePlayer* Player)
			//{
			//	const float draw_offset = WindowPos.y - (70) - ImageSize;
			//	const ImVec2 rect_start = { WindowPos.x - ImageSize - 70, draw_offset };
			//	const ImVec2 rect_end = { WindowPos.x + ImageSize + 6 * ImageSpace - 70, draw_offset + 2 * ImageSize };
			//	for (int i = 1; i <= 7; ++i) {
			//		const ImVec2 draw_start = { rect_start.x + (i - 1) * ImageSpace, rect_start.y };
			//		const ImVec2 draw_end = { rect_start.x + i * ImageSpace - 2, rect_end.y };
			//		const c_texture& texture = texture_cache.get_texture(Player->GetClothingItems(Player->GetClothingItemsList(), i));
			//		ImGui::GetBackgroundDrawList()->AddRectFilled(draw_start, draw_end, ImColor(120, 120, 120, 120));
			//		if (texture.texture != nullptr) {
			//			ImGui::GetBackgroundDrawList()->AddImage(reinterpret_cast<void*>(texture.texture), draw_start, draw_end, ImVec2(0, 0), ImVec2(1, 1));
			//		}
			//	}
			//	const float draw_offset2 = WindowPos.y - ImageSize;
			//	const ImVec2 rect_start2 = { WindowPos.x - ImageSize - 40, draw_offset2 };
			//	const ImVec2 rect_end2 = { WindowPos.x + ImageSize + 5 * ImageSpace - 40, draw_offset2 + 2 * ImageSize };
			//	for (int i = 1; i <= 6; ++i) {
			//		const ImVec2 draw_start = { rect_start2.x + (i - 1) * ImageSpace, rect_start2.y };
			//		const ImVec2 draw_end = { rect_start2.x + i * ImageSpace - 2, rect_end2.y };
			//		const c_texture& texture = texture_cache.get_texture(Player->GetBeltItems(Player->GetItemsList(), i));
			//		const c_texture& weapon_texture = texture_cache.get_texture(Player->GetActiveWeaponText().c_str());
			//		ImGui::GetBackgroundDrawList()->AddRectFilled(draw_start, draw_end, ImColor(120, 120, 120, 120));
			//		if (texture.item_name == weapon_texture.item_name) {
			//			ImGui::GetBackgroundDrawList()->AddRect(draw_start, draw_end, ImColor(0, 0, 0, 255), 1.f, NULL, 2.f);
			//		}
			//		if (texture.texture != nullptr) {
			//			ImGui::GetBackgroundDrawList()->AddImage(reinterpret_cast<void*>(texture.texture), draw_start, draw_end, ImVec2(0, 0), ImVec2(1, 1));
			//		}
			//	}
			//}

			//const uintptr_t GetItemsList() {
			//	const uintptr_t Inventory = safe_read(reinterpret_cast<uintptr_t>(this) + oPlayerInventory, uintptr_t);
			//	const uintptr_t Belt = safe_read(Inventory + 0x28, uintptr_t);
			//	const uintptr_t ItemList = safe_read(Belt + 0x40, uintptr_t); // public List<Item> itemList; // 0x40
			//	const uintptr_t LastItemList = safe_read(ItemList + 0x10, uintptr_t);
			//	return LastItemList;
			//}
			//const std::string GetBeltItems(uintptr_t ItemsList, int Slot) {
			//	const uintptr_t SlotItem = safe_read(ItemsList + ((Slot - 1) * 8) + 0x20, uintptr_t);
			//	if (!SlotItem)  return IXOR("");
			//	const uintptr_t Item1Info = safe_read(SlotItem + 0x18, uintptr_t);
			//	if (!Item1Info) return IXOR("");
			//	const uintptr_t ItemDisplayName = safe_read(Item1Info + 0x20, uintptr_t);
			//	if (!ItemDisplayName) return IXOR("");
			//	const std::wstring Name = safe_readwstring(ItemDisplayName + 0x14, 1024);
			//	const std::string output(Name.begin(), Name.end());
			//	return output;
			//}
			//const uintptr_t GetClothingItemsList() {
			//	const uintptr_t Inventory = safe_read(reinterpret_cast<uintptr_t>(this) + oPlayerInventory, uintptr_t);
			//	const uintptr_t Belt = safe_read(Inventory + 0x30, uintptr_t);
			//	const uintptr_t ItemList = safe_read(Belt + 0x40, uintptr_t);// public List<Item> itemList; // 0x40
			//	const uintptr_t LastItemList = safe_read(ItemList + 0x10, uintptr_t);
			//	return LastItemList;
			//}
			//const const  std::string GetClothingItems(uintptr_t ItemsList, int Slot) {
			//	constexpr uintptr_t SlotOffsets[] = { 0x20, 0x28, 0x30, 0x38, 0x40, 0x48, 0x50 };
			//	if (Slot < 1 || Slot > 7)  return IXOR("");
			//	const uintptr_t SlotItem = safe_read(ItemsList + SlotOffsets[Slot - 1], uintptr_t);
			//	if (!SlotItem) return IXOR("");
			//	const uintptr_t Item1Info = safe_read(SlotItem + 0x18, uintptr_t);
			//	if (!Item1Info) return IXOR("");
			//	const uintptr_t ItemDisplayName = safe_read(Item1Info + 0x20, uintptr_t);
			//	if (!ItemDisplayName) return IXOR("");
			//	const std::wstring Name = safe_readwstring(ItemDisplayName + 0x14, 1024);
			//	const std::string output(Name.begin(), Name.end());
			//	return output;
			//}

			//const float arttirbakim = NameTag ? 8 : 0;
			//const float ImageSize = 8;
			//if (ClothItems) {
			//	const float draw_offset = tempHead.y - (35 + arttirbakim) - ImageSize;
			//	const ImVec2 rect_start = { tempHead.x - ImageSize - 48, draw_offset };
			//	const ImVec2 rect_end = { tempHead.x + ImageSize + 6 * 17 - 48, draw_offset + 2 * ImageSize };
			//	ImVec2 draw_start[7];
			//	ImVec2 draw_end[7];
			//	c_texture texture[7];
			//	for (int i = 0; i < 7; ++i) {
			//		draw_start[i] = { rect_start.x + i * 17, rect_start.y };
			//		draw_end[i] = { rect_start.x + (i + 1) * 17, rect_end.y };
			//		texture[i] = texture_cache.get_texture(Player->GetClothingItems(Player->GetClothingItemsList(), i + 1));
			//	}
			//	ImDrawList* draw_list = ImGui::GetBackgroundDrawList();
			//	ImGui::GetBackgroundDrawList()->AddRectFilled(rect_start, rect_end, ImColor(120, 120, 120, 120));
			//	for (int i = 0; i < 7; ++i) {
			//		if (texture[i].texture != nullptr) {
			//			draw_list->AddImage(reinterpret_cast<void*>(texture[i].texture), draw_start[i], draw_end[i], ImVec2(0, 0), ImVec2(1, 1));
			//		}
			//	}
			//}
			//if (BeltItems) {
			//	const float draw_offset = tempHead.y - (18 + arttirbakim) - ImageSize;
			//	const ImVec2 rect_start = { tempHead.x - ImageSize - 38, draw_offset };
			//	const ImVec2 rect_end = { tempHead.x + ImageSize + 5 * 17 - 38, draw_offset + 2 * ImageSize };
			//	ImVec2 draw_start[7];
			//	ImVec2 draw_end[7];
			//	c_texture texture[7];
			//	for (int i = 0; i < 6; ++i) {
			//		draw_start[i] = { rect_start.x + i * 17, rect_start.y };
			//		draw_end[i] = { rect_start.x + (i + 1) * 17, rect_end.y };
			//		texture[i] = texture_cache.get_texture(Player->GetBeltItems(Player->GetItemsList(), i + 1));
			//	}
			//	ImDrawList* draw_list = ImGui::GetBackgroundDrawList();
			//	ImGui::GetBackgroundDrawList()->AddRectFilled(rect_start, rect_end, ImColor(120, 120, 120, 120));
			//	for (int i = 0; i < 6; ++i) {
			//		if (texture[i].texture != nullptr) {
			//			draw_list->AddImage(reinterpret_cast<void*>(texture[i].texture), draw_start[i], draw_end[i], ImVec2(0, 0), ImVec2(1, 1));
			//		}
			//	}
			//}

			if (config.Includes.Visual.nameesp)
			{
				auto display_name = ply->_displayName ( )->buffer ( );
				auto name = std::string ( display_name.begin ( ), display_name.end ( ) );
				if ( name.empty ( ) ) continue;

				render::add_text ( { top.x - ( ImGui::CalcTextSize ( name.c_str ( ) ).x / 2 ), top.y - 14 - text_padding }, main_color, name.c_str ( ) );
			}

			if ( config.Includes.Visual.distance )
			{
				auto distance_string = std::to_string ( ( int ) distance ) + e ( "m" );
				if ( distance_string.empty ( ) ) continue;

				render::add_text ( { top.x - ( ImGui::CalcTextSize ( distance_string.c_str ( ) ).x / 2 ), top.y - 24 - text_padding }, main_color, distance_string.c_str ( ) );
			}

			//const float x = LocalGamePos.z - PlayerGamePos.z;
			//const float y = LocalGamePos.x - PlayerGamePos.x;
			//float distance = sqrtf(x * x + y * y);
			//const float num = atan2f(y, x) * 57.29578f - 270.f - LocalEulerAngles.y;
			//if (RadarESP)
			//{
			//	if (distance <= 129.f)
			//	{
			//		const float cos_num = cosf(num * 0.0174532924f);
			//		const float sin_num = sinf(num * 0.0174532924f);
			//		const float point_pos_x = distance * cos_num;
			//		const float point_pos_y = distance * sin_num;
			//		const float center_x = WindowPosRadar.x - 129.f;
			//		const ImVec2 point_pos(center_x + point_pos_x - 3.f, WindowPosRadar.y + 129.f + point_pos_y);
			//		if (RealPlayer) ImGui::GetBackgroundDrawList()->AddCircle(point_pos, 2.f, ImColor(255, 0, 0), 1000, 1);
			//		else ImGui::GetBackgroundDrawList()->AddCircle(point_pos, 2.f, ImColor(color), 1000, 1);
			//	}

			if ( config.Includes.Visual.helditem_esp )
			{
				auto buffer = ply->get_projectile ( )->shortname ( );
				auto weapon_string = std::string ( buffer.begin ( ), buffer.end ( ) );
				if ( weapon_string.empty ( ) ) continue;

				render::add_text ( { bottom.x - ( ImGui::CalcTextSize ( weapon_string.c_str ( ) ).x / 2 ), bottom.y + 18 }, main_color, weapon_string.c_str ( ) );
			}

			if (config.Includes.Visual.box)
			{//box
				gui->AddRect({ top.x - size.y / 4.00f, top.y }, { bottom.x + size.y / 4.00f, bottom.y + 3.00f }, ImColor{ black_color.x, black_color.y, black_color.x, black_color.w }, 0.00f, 0, 4.00f);
				gui->AddRect({ top.x - size.y / 4.00f, top.y }, { bottom.x + size.y / 4.00f, bottom.y + 3.00f }, ImColor{ 146, 157, 223 });
			}
		}
	}
}