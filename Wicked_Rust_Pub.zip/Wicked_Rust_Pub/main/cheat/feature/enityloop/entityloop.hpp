#pragma once
#include "../../../driver/imports.hpp"

class prefab_vector
{
public:
	prefab_vector ( geo::vec3_t prefabpos, std::string prefabname, float dist, geo::vec4_t clr = geo::vec4_t{ 255.00f, 255.00f, 255.00f, 255.00f } )
	{
		this->cache.position = prefabpos;
		this->cache.name = prefabname;
		this->cache.distance = dist;
		this->cache.color = clr;
	}
	struct
	{
		geo::vec3_t position = { 0.00f, 0.00f, 0.00f };
		std::string name;
		float distance = 0.00f;
		geo::vec4_t color = geo::vec4_t{ 255.00f, 255.00f, 255.00f, 255.00f };
	}cache;
};

class entity_vector
{
public:
	entity_vector ( c_base_player* player, geo::vec3_t playerpos, geo::vec3_t localpos, float dist, bool is_team, bool is_visible )
	{
		this->cache.player = player;

		this->cache.player_pos = playerpos;
		this->cache.local_pos = localpos;

		this->cache.distance = dist;

		this->cache.teammate = is_team;
		this->cache.visible = is_visible;
	}
	struct
	{
		c_base_player* player = nullptr;

		geo::vec3_t player_pos = { 0.00f, 0.00f, 0.00f };
		geo::vec3_t local_pos = { 0.00f, 0.00f, 0.00f };

		float distance = 0.00f;

		bool teammate = false;
		bool visible = false;
	}cache;
};

class loco
{
public:
	c_camera* camera;
	c_tod_sky* tod_sky;
	c_skinnable* skinnable;
	c_convar_admin* convar_admin;
	c_convar_client* convar_client;
	c_convar_graphics* convar_graphics;

	c_base_player* player;

	std::vector< entity_vector> player_list;
	std::vector< prefab_vector> prefab_list;

	std::mutex cache_mutex;
}rainy;

namespace entity_loop
{
	c_base_player* list_player;
	auto get_list ( ) -> void
	{
		rainy.camera = c_camera::instance ( );
		if ( !rainy.camera ) return;

		rainy.tod_sky = c_tod_sky::instance ( );
		if ( !rainy.tod_sky ) return;

		rainy.skinnable = c_skinnable::instance ( );
		if ( !rainy.skinnable ) return;

		rainy.player = c_base_player::instance ( );
		if ( !rainy.player ) return;

		rainy.convar_admin = c_convar_admin::instance ( );
		if ( !rainy.convar_admin ) return;

		rainy.convar_client = c_convar_client::instance ( );
		if ( !rainy.convar_client ) return;

		rainy.convar_graphics = c_convar_graphics::instance ( );
		if ( !rainy.convar_graphics ) return;

		const auto client_entities = c_base_networkable::get_base_entity ( )->get_client_entities ( );
		if ( !client_entities ) return;

		std::vector<entity_vector> base_player_list;
		std::vector<prefab_vector> base_prefab_list;

		for ( std::uint32_t i = 0; i < client_entities->size ( ); i++ )
		{
			const auto object = driver.read<c_object*> ( client_entities->get ( i ) + 0x10 );
			if ( !object ) continue;

			const auto object_class = object->object_class ( );
			if ( !object_class ) continue;

			const auto entity = object->get_instance ( );
			if ( !entity ) continue;

			auto object_name = object_class->get_name ( );

			auto object_position = object_class->get_position ( );

			auto local_bone = rainy.player->get_bone_transform ( systems::player_bones::head )->get_position ( );
			if ( object_class->tag ( ) == 6 )
			{
				if ( !entity->is_valid ( rainy.player ) ) continue; list_player = entity;

				auto player_bone = entity->get_bone_transform ( systems::player_bones::head )->get_position ( );

				const auto distance = player_bone.distance ( local_bone );
				if ( distance > config.Includes.Visual.PlayerDistance ) continue; // max distance for esp - add to menu and config system
				{   
					{//chams
						const auto ply_model = entity->playerModel();
						if (!ply_model) continue;

						const auto skin = (ply_model->skinType() == 1 ? ply_model->FemaleSkin() : ply_model->MaleSkin());

						const auto skin_set = skin->skinSet();
						if (!skin_set) continue;

						for (std::uint32_t i = 0; i < skin_set->size(); i++)
						{
							const auto set = skin_set->get(i);
							if (!set) continue;

							if (config.Includes.Visual.selectedChams == 1)
							{
								const auto redflat = driver.read_chain<std::uintptr_t>(driver.game_assembly, { Offsets::Vars::m_TodSky_c, 0xB8 ,0x20});
								set->set_eye_material(redflat);
								set->set_body_material(redflat);
								set->set_head_material(redflat);
							}
							if (config.Includes.Visual.selectedChams == 2)
							{
								const auto redGlow = driver.read_chain<std::uintptr_t>(driver.game_assembly, { Offsets::Vars::m_LaserBeam_c, 0xB8 ,0x0, 0x120, 0x10 });
								set->set_eye_material(redGlow);
								set->set_body_material(redGlow);
								set->set_head_material(redGlow);
							}
							if (config.Includes.Visual.selectedChams == 4)
							{
								const auto punkinglow = driver.read_chain<std::uintptr_t>(driver.game_assembly, { Offsets::Vars::m_AssetPool_c, 0xB8, 0x90, 0x118 });
								set->set_eye_material(punkinglow);
								set->set_body_material(punkinglow);
								set->set_head_material(punkinglow);
							}
							if (config.Includes.Visual.selectedChams == 5)
							{
								const auto plantchams = driver.read_chain<std::uintptr_t>(driver.game_assembly, { Offsets::Vars::m_CodeLock_c, 0xB8 , 0xd0, 0x68, 0x138, 0x2d0 });
								set->set_eye_material(plantchams);
								set->set_body_material(plantchams);
								set->set_head_material(plantchams);
							}
							if (config.Includes.Visual.selectedChams == 6)
							{
								const auto weirdbluered = driver.read_chain<std::uintptr_t>(driver.game_assembly, { Offsets::Vars::m_CodeLock_c, 0xB8 ,0x198, 0x88 });
								set->set_eye_material(weirdbluered);
								set->set_body_material(weirdbluered);
								set->set_head_material(weirdbluered);
							}
							if (config.Includes.Visual.selectedChams == 7)
							{
								const auto COALS = driver.read_chain<std::uintptr_t>(driver.game_assembly, { Offsets::Vars::m_VLB_Config_c, 0xB8 ,0xe0, 0x38, 0x208 });
								set->set_eye_material(COALS);
								set->set_body_material(COALS);
								set->set_head_material(COALS);
							}
							if (config.Includes.Visual.selectedChams == 8)
							{
								const auto iron = driver.read_chain<std::uintptr_t>(driver.game_assembly, { Offsets::Vars::m_VLB_Config_c, 0xB8 ,0xe0, 0x38, 0x1a8 });
								set->set_eye_material(iron);
								set->set_body_material(iron);
								set->set_head_material(iron);
							}
						}
					}
					{//clothing chams
						entity->set_needsClothesRebuild(true);
						auto skinnables = rainy.skinnable->All();
						for (std::uint32_t i = 0; i < skinnables->size(); i++)
						{
							auto skin = skinnables->get(i);
							if (!skin) continue;

							auto groups = skin->Groups();

							auto category = skin->Category();

							for (std::uint32_t i = 0; i < groups->size(); i++)
							{
								if (config.Includes.Visual.selectedClothingChams == 1)
								{
									const auto redflat = driver.read_chain<std::uintptr_t>(driver.game_assembly, { Offsets::Vars::m_TodSky_c, 0xB8 ,0x20 });
									auto group = groups->get(i);
									if (!group) continue;

									if (category == systems::category::footwear || category == systems::category::mask || category == systems::category::gloves ||
										category == systems::category::hat || category == systems::category::jacket || category == systems::category::pants ||
										category == systems::category::shirt)
										group->material()->set_value(driver.read<std::uintptr_t>(redflat + 0x10));
								}
								if (config.Includes.Visual.selectedClothingChams == 2)
								{
									const auto redGlow = driver.read_chain<std::uintptr_t>(driver.game_assembly, { Offsets::Vars::m_LaserBeam_c, 0xB8 ,0x0, 0x120, 0x10 });
									auto group = groups->get(i);
									if (!group) continue;

									if (category == systems::category::footwear || category == systems::category::mask || category == systems::category::gloves ||
										category == systems::category::hat || category == systems::category::jacket || category == systems::category::pants ||
										category == systems::category::shirt)
										group->material()->set_value(driver.read<std::uintptr_t>(redGlow + 0x10));
								}
								if (config.Includes.Visual.selectedClothingChams == 4)
								{
									const auto puniknglow = driver.read_chain<std::uintptr_t>(driver.game_assembly, { Offsets::Vars::m_AssetPool_c, 0xB8 , 0x90, 0x118 });
									auto group = groups->get(i);
									if (!group) continue;

									if (category == systems::category::footwear || category == systems::category::mask || category == systems::category::gloves ||
										category == systems::category::hat || category == systems::category::jacket || category == systems::category::pants ||
										category == systems::category::shirt)
										group->material()->set_value(driver.read<std::uintptr_t>(puniknglow + 0x10));
								}
								if (config.Includes.Visual.selectedClothingChams == 5)
								{
									const auto plantchams = driver.read_chain<std::uintptr_t>(driver.game_assembly, { Offsets::Vars::m_CodeLock_c, 0xB8 , 0xd0, 0x68, 0x138, 0x2d0 });									
									auto group = groups->get(i);
									if (!group) continue;

									if (category == systems::category::footwear || category == systems::category::mask || category == systems::category::gloves ||
										category == systems::category::hat || category == systems::category::jacket || category == systems::category::pants ||
										category == systems::category::shirt)
										group->material()->set_value(driver.read<std::uintptr_t>(plantchams + 0x10));
								}
								if (config.Includes.Visual.selectedClothingChams == 6)
								{
									const auto weirdbluered = driver.read_chain<std::uintptr_t>(driver.game_assembly, { Offsets::Vars::m_CodeLock_c, 0xB8 ,0x150, 0x70, 0x198, 0x1b0 });
									auto group = groups->get(i);
									if (!group) continue;

									if (category == systems::category::footwear || category == systems::category::mask || category == systems::category::gloves ||
										category == systems::category::hat || category == systems::category::jacket || category == systems::category::pants ||
										category == systems::category::shirt)
										group->material()->set_value(driver.read<std::uintptr_t>(weirdbluered + 0x10));
								}
								if (config.Includes.Visual.selectedClothingChams == 7)
								{
									const auto COALS = driver.read_chain<std::uintptr_t>(driver.game_assembly, { Offsets::Vars::m_VLB_Config_c, 0xB8 ,0xe0, 0x38, 0x208 });
									auto group = groups->get(i);
									if (!group) continue;

									if (category == systems::category::footwear || category == systems::category::mask || category == systems::category::gloves ||
										category == systems::category::hat || category == systems::category::jacket || category == systems::category::pants ||
										category == systems::category::shirt)
										group->material()->set_value(driver.read<std::uintptr_t>(COALS + 0x10));
								}
								if (config.Includes.Visual.selectedClothingChams == 8)
								{
									const auto iron = driver.read_chain<std::uintptr_t>(driver.game_assembly, { Offsets::Vars::m_VLB_Config_c, 0xB8 ,0xe0, 0x38, 0x1a8 });
									auto group = groups->get(i);
									if (!group) continue;

									if (category == systems::category::footwear || category == systems::category::mask || category == systems::category::gloves ||
										category == systems::category::hat || category == systems::category::jacket || category == systems::category::pants ||
										category == systems::category::shirt)
										group->material()->set_value(driver.read<std::uintptr_t>(iron + 0x10));
								}
								
							}
						}
						entity->set_needsClothesRebuild(true);
					}

					{//gun chams
						auto skinnables = rainy.skinnable->All();
						for (std::uint32_t i = 0; i < skinnables->size(); i++)
						{
							auto skin = skinnables->get(i);
							if (!skin) continue;

							auto groups = skin->Groups();

							auto category = skin->Category();

							for (std::uint32_t i = 0; i < groups->size(); i++)
							{
								if (config.Includes.Visual.selectedWeaponChams == 1)
								{
									const auto redflat = driver.read_chain<std::uintptr_t>(driver.game_assembly, { Offsets::Vars::m_TodSky_c, 0xB8 ,0x20 });
									auto group = groups->get(i);
									if (!group) continue;

									if (category == systems::category::weapon)
										group->material()->set_value(driver.read<std::uintptr_t>(redflat + 0x10));
								}
								if (config.Includes.Visual.selectedWeaponChams == 2)
								{
									const auto Watter = driver.read_chain<std::uintptr_t>(driver.game_assembly, { Offsets::Vars::m_LaserBeam_c, 0xB8 ,0x0, 0x120, 0x10 });
									auto group = groups->get(i);
									if (!group) continue;

									if (category == systems::category::weapon)
										group->material()->set_value(driver.read<std::uintptr_t>(Watter + 0x10));
								}
								if (config.Includes.Visual.selectedWeaponChams == 3)
								{
									const auto punkinglow = driver.read_chain<std::uintptr_t>(driver.game_assembly, { Offsets::Vars::m_AssetPool_c, 0xB8 , 0x90, 0x118 });
									auto group = groups->get(i);

									if (!group) continue;

									if (category == systems::category::weapon)
										group->material()->set_value(driver.read<std::uintptr_t>(punkinglow + 0x10));
								}
								if (config.Includes.Visual.selectedWeaponChams == 4)
								{
									const auto plantchams = driver.read_chain<std::uintptr_t>(driver.game_assembly, { Offsets::Vars::m_CodeLock_c, 0xB8 , 0xd0, 0x68, 0x138, 0x2d0 });
									auto group = groups->get(i);
									if (!group) continue;

									if (category == systems::category::weapon)
										group->material()->set_value(driver.read<std::uintptr_t>(plantchams + 0x10));
								}
								if (config.Includes.Visual.selectedWeaponChams == 5)
								{
									const auto COALS = driver.read_chain<std::uintptr_t>(driver.game_assembly, { Offsets::Vars::m_VLB_Config_c, 0xB8 ,0xe0, 0x38, 0x208 });
									auto group = groups->get(i);
									if (!group) continue;

									if (category == systems::category::weapon)
										group->material()->set_value(driver.read<std::uintptr_t>(COALS + 0x10));
								}
								if (config.Includes.Visual.selectedWeaponChams == 6)
								{
									const auto iron = driver.read_chain<std::uintptr_t>(driver.game_assembly, { Offsets::Vars::m_VLB_Config_c, 0xB8 ,0xe0, 0x38, 0x1a8 });
									auto group = groups->get(i);
									if (!group) continue;

									if (category == systems::category::weapon)
										group->material()->set_value(driver.read<std::uintptr_t>(iron + 0x10));
								}
							}
						}
						entity->set_needsClothesRebuild(true);
					}

				}

				base_player_list.push_back ( { entity, player_bone, local_bone, distance, entity->is_teammate ( rainy.player ), entity->playerModel ( )->visible ( ) } );
			}
			{ //prefab esp
				auto distance = object_position.distance ( local_bone );
				if ( distance > config.Includes.Visual.PrefabDistance) continue; // max prefab distance

				if ( config.Includes.Visual.stoneore) { if ( strstr ( object_name.c_str ( ), e ( "stone-collectable.prefab" ) ) ) { base_prefab_list.push_back ( { object_position, e ( "stone" ), distance } ); } }
				if (config.Includes.Visual.sulfurore) { if ( strstr ( object_name.c_str ( ), e ( "sulfur-collectable.prefab" ) ) ) { base_prefab_list.push_back ( { object_position, e ( "sulfur" ), distance } ); } }
				if (config.Includes.Visual.metalore) { if ( strstr ( object_name.c_str ( ), e ( "metal-collectable.prefab" ) ) ) { base_prefab_list.push_back ( { object_position, e ( "metal" ), distance } ); } }
				if (config.Includes.Visual.wood) { if ( strstr ( object_name.c_str ( ), e ( "wood-collectable.prefab" ) ) ) { base_prefab_list.push_back ( { object_position, e ( "wood" ), distance } ); } }
				if (config.Includes.Visual.hemp) { if ( strstr ( object_name.c_str ( ), e ( "hemp-collectable.prefab" ) ) ) { base_prefab_list.push_back ( { object_position, e ( "hemp" ), distance, geo::vec4_t ( 0.00f, 255.00f, 0.00f, 255.00f ) } ); } }
				if (config.Includes.Visual.stoneore) { if ( strstr ( object_name.c_str ( ), e ( "stone-ore.prefab" ) ) ) { base_prefab_list.push_back ( { object_position, e ( "stone ore" ), distance } ); } }
				if (config.Includes.Visual.sulfurore) { if ( strstr ( object_name.c_str ( ), e ( "sulfur-ore.prefab" ) ) ) { base_prefab_list.push_back ( { object_position, e ( "sulfur ore" ), distance, geo::vec4_t ( 255.00f, 255.00f, 0.00f, 255.00f ) } ); } }
				if (config.Includes.Visual.metalore) { if ( strstr ( object_name.c_str ( ), e ( "metal-ore.prefab" ) ) ) { base_prefab_list.push_back ( { object_position, e ( "metal ore" ), distance, geo::vec4_t ( 255.00f, 0.00f, 0.00f, 255.00f ) } ); } }
				if (config.Includes.Visual.corpsebackpack) { if ( strstr ( object_name.c_str ( ), e ( "item_drop_backpack.prefab" ) ) ) { base_prefab_list.push_back ( { object_position, e ( "backpack" ), distance } ); } }
				if (config.Includes.Visual.corpse) { if ( strstr ( object_name.c_str ( ), e ( "player_corpse.prefab" ) ) ) { base_prefab_list.push_back ( { object_position, e ( "corpse" ), distance } ); } }
				if (config.Includes.Visual.smallstash) { if ( strstr ( object_name.c_str ( ), e ( "small_stash_deployed.prefab" ) ) ) { base_prefab_list.push_back ( { object_position, e ( "stash" ), distance } ); } }
				if (config.Includes.Visual.cupboard) { if ( strstr ( object_name.c_str ( ), e ( "cupboard.tool.deployed.prefab" ) ) ) { base_prefab_list.push_back ( { object_position, e ( "toolcupboard" ), distance } ); } }
				if (config.Includes.Visual.woodenbox) { if ( strstr ( object_name.c_str ( ), e ( "box.wooden.large.prefab" ) ) ) { base_prefab_list.push_back ( { object_position, e ( "large box" ), distance } ); } }
				if (config.Includes.Visual.supplydrop) { if ( strstr ( object_name.c_str ( ), e ( "supply_drop.prefab" ) ) ) { base_prefab_list.push_back ( { object_position, e ( "air drop" ), distance } ); } }
				if (config.Includes.Visual.hackablecrate) { if ( strstr ( object_name.c_str ( ), e ( "codelockedhackablecrate.prefab" ) ) ) { base_prefab_list.push_back ( { object_position, e ( "locked crate" ), distance } ); } }
				if (config.Includes.Visual.autoturret) { if ( strstr ( object_name.c_str ( ), e ( "autoturret_deployed.prefab" ) ) ) { base_prefab_list.push_back ( { object_position, e ( "turret" ), distance } ); } }
				if (config.Includes.Visual.landmine) { if ( strstr ( object_name.c_str ( ), e ( "trap.landmine.prefab" ) ) ) { base_prefab_list.push_back ( { object_position, e ( "landmine" ), distance } ); } }
				if (config.Includes.Visual.flameturret) { if ( strstr ( object_name.c_str ( ), e ( "flameturret.deployed.prefab" ) ) ) { base_prefab_list.push_back ( { object_position, e ( "flame turret" ), distance } ); } }
				if (config.Includes.Visual.guntrap) { if ( strstr ( object_name.c_str ( ), e ( "guntrap.deployed" ) ) ) { base_prefab_list.push_back ( { object_position, e ( "shotgun trap" ), distance } ); } }
				if (config.Includes.Visual.beartrap) { if ( strstr ( object_name.c_str ( ), e ( "beartrap.prefab" ) ) ) { base_prefab_list.push_back ( { object_position, e ( "bear trap" ), distance } ); } }
				if (config.Includes.Visual.minicopter) { if ( strstr ( object_name.c_str ( ), e ( "minicopter.entity.prefab" ) ) ) { base_prefab_list.push_back ( { object_position, e ( "minicopter" ), distance } ); } }
				if (config.Includes.Visual.elitecrate) { if ( strstr ( object_name.c_str ( ), e ( "crate_elite.prefab" ) ) ) { base_prefab_list.push_back ( { object_position, e ( "elite crate" ), distance } ); } }
				if (config.Includes.Visual.normalcrate) { if ( strstr ( object_name.c_str ( ), e ( "crate_normal.prefab" ) ) ) { base_prefab_list.push_back ( { object_position, e ( "military crate" ), distance } ); } }
				if (config.Includes.Visual.normalcrate) { if ( strstr ( object_name.c_str ( ), e ( "crate_normal_2.prefab" ) ) ) { base_prefab_list.push_back ( { object_position, e ( "normal crate" ), distance } ); } }
				if (config.Includes.Visual.bradleycrate) { if ( strstr ( object_name.c_str ( ), e ( "bradley_crate.prefab" ) ) ) { base_prefab_list.push_back ( { object_position, e ( "bradley crate" ), distance } ); } }
				if (config.Includes.Visual.helicrate) { if ( strstr ( object_name.c_str ( ), e ( "heli_crate.prefab" ) ) ) { base_prefab_list.push_back ( { object_position, e ( "heli crate" ), distance } ); } }
				if (config.Includes.Visual.mushroom) { if ( strstr ( object_name.c_str ( ), e ( "mushroom-cluster-5.prefab" ) ) || strstr ( object_name.c_str ( ), e ( "mushroom-cluster-6.prefab" ) ) ) { base_prefab_list.push_back ( { object_position, e ( "mushrooms" ), distance } ); } }
				if (config.Includes.Visual.potato) { if ( strstr ( object_name.c_str ( ), e ( "potato-collectable.prefab" ) ) ) { base_prefab_list.push_back ( { object_position, e ( "potato" ), distance } ); } }
				if (config.Includes.Visual.bradley) { if ( strstr ( object_name.c_str ( ), e ( "bradleyapc.prefab" ) ) ) { base_prefab_list.push_back ( { object_position, e ( "bradley" ), distance } ); } }
				if (config.Includes.Visual.samsite) { if ( strstr ( object_name.c_str ( ), e ( "sam_site_turret_deployed.prefab" ) ) ) { base_prefab_list.push_back ( { object_position, e ( "sam site" ), distance } ); } }
			}
		}

		rainy.cache_mutex.lock ( );

		rainy.player_list = base_player_list;
		rainy.prefab_list = base_prefab_list;

		rainy.cache_mutex.unlock ( );
	}
}