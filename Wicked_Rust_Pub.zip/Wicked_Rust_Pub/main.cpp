#include "main/menu/window.hpp"
#include "main/Mapper/driverloader.h"
int main()
{
	int horizontal = 0, vertical = 0;
	int x = 350, y = 350; //// alta do�ru
	HWND consoleWindow = GetConsoleWindow();
	SetWindowLong(consoleWindow, GWL_STYLE, GetWindowLong(consoleWindow, GWL_STYLE) & ~WS_MAXIMIZEBOX & ~WS_SIZEBOX);
	HANDLE out = GetStdHandle(STD_OUTPUT_HANDLE);
	CONSOLE_CURSOR_INFO     cursorInfo;
	GetConsoleCursorInfo(out, &cursorInfo);
	SetConsoleCursorInfo(out, &cursorInfo);
	CONSOLE_FONT_INFOEX cfi;
	cfi.cbSize = sizeof(cfi);
	cfi.nFont = 0;
	cfi.dwFontSize.X = 0;
	cfi.dwFontSize.Y = 15;
	cfi.FontFamily = FF_DONTCARE;
	cfi.FontWeight = FW_NORMAL;
	wcscpy_s(cfi.FaceName, e(L"Consolas"));
	SetCurrentConsoleFontEx(GetStdHandle(STD_OUTPUT_HANDLE), FALSE, &cfi);
	HWND hwnd = GetConsoleWindow();
	MoveWindow(hwnd, 0, 0, x, y, TRUE);
	LONG lStyle = GetWindowLong(hwnd, GWL_STYLE);
	lStyle &= ~(WS_THICKFRAME | WS_MINIMIZEBOX | WS_MAXIMIZEBOX | WS_SYSMENU);
	SetWindowLong(hwnd, GWL_STYLE, lStyle);
	HANDLE console = GetStdHandle(STD_OUTPUT_HANDLE);
	CONSOLE_SCREEN_BUFFER_INFO csbi;
	GetConsoleScreenBufferInfo(console, &csbi);
	COORD scrollbar = {
		csbi.srWindow.Right - csbi.srWindow.Left + 1,
		csbi.srWindow.Bottom - csbi.srWindow.Top + 1
	};
	if (console == 0)
		throw 0;
	else
		SetConsoleScreenBufferSize(console, scrollbar);
	SetWindowLong(hwnd, GWL_EXSTYLE, GetWindowLong(hwnd, GWL_EXSTYLE) | WS_EX_LAYERED);
	SetLayeredWindowAttributes(hwnd, 0, 225, LWA_ALPHA);
	SetPriorityClass(GetCurrentProcess(), REALTIME_PRIORITY_CLASS);
	BypassLoader();
	ShowWindow(GetConsoleWindow(), SW_SHOW);
	// config init
	{
		std::filesystem::create_directories(e("C:\\wicked\\configs"));
		if (!std::filesystem::exists(e("C:\\wicked\\configs\\legit.cfg")))
		{
			std::ofstream(e("C:\\wicked\\configs\\legit.cfg"));
			std::ofstream(e("C:\\wicked\\configs\\semi_rage.cfg"));
			std::ofstream(e("C:\\wicked\\configs\\rage.cfg"));
			std::ofstream(e("C:\\wicked\\configs\\custom.cfg"));
		}
		config.run();
	}

	driver.init(); // driver init
	{
		driver.game_assembly = utils::get_module(utils::globals::process_id, e(L"GameAssembly.dll")); // get gameassembly module
		driver.unity_player = utils::get_module(utils::globals::process_id, e(L"UnityPlayer.dll")); // get unityplayer module

		std::thread([&]() // check if the game is open and get system width and height
			{
				while (true)
				{
					std::this_thread::sleep_for(std::chrono::milliseconds(250));

					config.Includes.Setiings.width = GetSystemMetrics(SM_CXSCREEN);
					config.Includes.Setiings.height = GetSystemMetrics(SM_CYSCREEN);

					if (!utils::get_process_id(e("RustClient.exe"))) exit(0);
				}
			}
		).detach();

		std::thread([&]() // entity loop
			{
				while (true)
				{
					std::this_thread::sleep_for(std::chrono::milliseconds(750));

					entity_loop::get_list();
				}
			}
		).detach();

		std::thread([&]() // aimbot loop
			{
				auto next_frame = std::chrono::steady_clock::now();
				while (true)
				{
					std::this_thread::sleep_for(std::chrono::milliseconds(1));

					aimbot::aimbot_loop();
				}
			}
		).detach();

		std::thread([&]() // window loop
			{
				while (true)
				{
					std::this_thread::sleep_for(std::chrono::milliseconds(5));

					window::create_window(window::render_menu);
				}
			}
		).detach();

		std::thread([&]() // 0 ms loop
			{
				while (true)
				{
					features::fast_features();
				}
			}
		).detach();

		std::thread([&]() // weapon feature loop
			{
				while (true)
				{
					std::this_thread::sleep_for(std::chrono::milliseconds(1));

					features::weapon_features();
				}
			}
		).detach();

		std::thread([&]() // movement feature loop
			{
				while (true)
				{
					std::this_thread::sleep_for(std::chrono::milliseconds(1));

					features::movement_features();
				}
			}
		).detach();

		std::thread([&]() // misc feature loop
			{
				while (true)
				{
					std::this_thread::sleep_for(std::chrono::milliseconds(1));

					features::misc_features();
				}
			}
		).detach();
	}
	Sleep(-1);
}