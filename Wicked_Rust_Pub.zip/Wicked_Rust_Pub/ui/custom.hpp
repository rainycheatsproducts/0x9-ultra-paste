#pragma once
#define  IMGUI_DEFINE_MATH_OPERATORS
#include "imgui.h"
#include "imgui_internal.h"
#include <string>
#include <vector>
#include <functional>
using namespace std;

#define to_vec4( r, g, b, a ) ImColor( r / 255.f, g / 255.f, b / 255.f, a )

class c_custom {

public:
    float m_anim = 0.f;
    int m_tab = 0;
    vector < const char* > tabs = { "Aim", "Visuals","World", "Misc", "Config"}, tabs_icons = { "N", "I", "H", "T", "B" }; //I esp H world esp B for setting
    int m_rage_subtab = 0;
    vector < const char* > rage_subtabs = {};

    int m_visuals_subtab = 0;
    vector < const char* > visuals_subtabs = {};
    float col_buf[4] = { 1.f, 1.f, 1.f, 1.f };
    int accent_color[4] = { 138, 138, 138 };

    ImColor get_accent_color( float a = 1.f )
    {
        return to_vec4( accent_color[0], accent_color[1], accent_color[2], a );
    }

};

inline c_custom custom;
